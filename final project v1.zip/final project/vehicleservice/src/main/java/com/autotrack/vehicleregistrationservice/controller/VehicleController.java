package com.autotrack.vehicleregistrationservice.controller;

import com.autotrack.vehicleregistrationservice.dto.VehicleDTO;
import com.autotrack.vehicleregistrationservice.model.Vehicle;
import com.autotrack.vehicleregistrationservice.service.VehicleService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    private final VehicleService service;

    public VehicleController(VehicleService service) {
        this.service = service;
    }

    // Notice we now expect X-USER-ID as a Long
    @PostMapping("/new")
    public VehicleDTO registerVehicle(
            @RequestHeader("X-USER-ID") Long customerId,
            @RequestBody @Valid VehicleDTO dto) {

        Vehicle vehicle = new Vehicle();
        vehicle.setVin(dto.getVin());
        vehicle.setModel(dto.getModel());
        vehicle.setYear(dto.getYear());
        vehicle.setStatus(dto.getStatus());

        Vehicle savedVehicle = service.registerVehicleForUser(customerId, vehicle);

        return mapToDTO(savedVehicle);
    }

    @GetMapping("/customer")
    public List<VehicleDTO> myVehicles(
            @RequestHeader("X-USER-ID") Long customerId) {

        return service.getVehiclesForUser(customerId)
                .stream()
                .map(this::mapToDTO)
                .toList();
    }

    @GetMapping("/customer/{vId}")
    public VehicleDTO getCustomerVehicleById(
            @RequestHeader("X-USER-ID") Long customerId,
            @PathVariable Long vId // Added this to capture the ID from the URL
    ){
        // Calling the service method we just created
        Vehicle vehicle = service.getVehicleByIdForUser(customerId, vId);

        // Converting the entity to DTO for the Postman response
        return mapToDTO(vehicle);
    }

    @PutMapping("/customer/{vehicleId}")
    public VehicleDTO updateVehicle(
            @RequestHeader("X-USER-ID") Long customerId,
            @PathVariable Long vehicleId,
            @RequestBody @Valid VehicleDTO dto) {

        Vehicle updatedVehicle = new Vehicle();
        updatedVehicle.setVin(dto.getVin());
        updatedVehicle.setModel(dto.getModel());
        updatedVehicle.setYear(dto.getYear());
        updatedVehicle.setStatus(dto.getStatus());

        Vehicle savedVehicle = service.updateVehicleForUser(customerId, vehicleId, updatedVehicle);

        return mapToDTO(savedVehicle);
    }

    @DeleteMapping("/customer/{vehicleId}")
    public void deleteVehicle(
            @RequestHeader("X-USER-ID") Long customerId,
            @PathVariable Long vehicleId) {

        service.deleteVehicleForUser(customerId, vehicleId);
    }

    // Extracted for cleaner code
    private VehicleDTO mapToDTO(Vehicle vehicle) {
        return new VehicleDTO(
                vehicle.getVehicleId(),
                vehicle.getVin(),
                vehicle.getModel(),
                vehicle.getYear(),
                vehicle.getStatus()
        );
    }
}