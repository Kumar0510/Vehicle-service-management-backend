
package com.autotrack.vehicleregistrationservice.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler({MethodArgumentNotValidException.class})
    public ResponseEntity<?> handleValidationErrors(MethodArgumentNotValidException ex) {
        logger.warn("Validation failed");
        Map<String, String> errors = new HashMap();
        ex.getBindingResult().getFieldErrors().forEach((error) -> errors.put(error.getField(), error.getDefaultMessage()));
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("timestamp", LocalDateTime.now(), "status", 400, "error", "Validation Failed", "messages", errors));
    }

    @ExceptionHandler({RuntimeException.class})
    public ResponseEntity<?> handleRuntimeException(RuntimeException ex) {
        logger.warn("Handled runtime exception: {}", ex.getMessage());
        HttpStatus status;
        String message;
        switch (ex.getMessage()) {
            case "USER_NOT_FOUND":
                status = HttpStatus.NOT_FOUND;
                message = "User not found";
                break;
            case "CUSTOMER_NOT_FOUND":
                status = HttpStatus.NOT_FOUND;
                message = "Customer profile not found";
                break;
            case "AGENT_NOT_FOUND":
                status = HttpStatus.NOT_FOUND;
                message = "Service agent profile not found";
                break;
            case "VEHICLE_NOT_FOUND":
                status = HttpStatus.NOT_FOUND;
                message = "Vehicle not found";
                break;
            case "DUPLICATE_VIN":
                status = HttpStatus.CONFLICT;
                message = "Vehicle with this VIN already exists";
                break;
            case "ACCESS_DENIED":
                status = HttpStatus.FORBIDDEN;
                message = "You are not allowed to access this resource";
                break;
            default:
                status = HttpStatus.INTERNAL_SERVER_ERROR;
                message = "An unexpected error occurred";
        }

        return ResponseEntity.status(status).body(Map.of("timestamp", LocalDateTime.now(), "status", status.value(), "error", status.getReasonPhrase(), "message", message));
    }
}
