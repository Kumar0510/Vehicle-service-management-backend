package com.autotrack.vehicleregistrationservice.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDTO {

    private Long vehicleId;

    @NotBlank(message = "VIN is required")
    private String vin;

    @NotBlank(message = "Vehicle model is required")
    private String model;

    @Min(1990)
    @Max(2100)
    private int year;

    @NotBlank(message = "Vehicle status is required")
    private String status;
}