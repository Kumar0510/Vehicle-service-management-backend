package com.autotrack.vehicleregistrationservice.service;

import com.autotrack.vehicleregistrationservice.model.Vehicle;
import com.autotrack.vehicleregistrationservice.repository.VehicleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleService {
    private static final Logger logger = LoggerFactory.getLogger(VehicleService.class);

    private final VehicleRepository vehicleRepo;

    // Constructor injection (Spring automatically wires this)
    public VehicleService(VehicleRepository vehicleRepo) {
        this.vehicleRepo = vehicleRepo;
    }

    public Vehicle getVehicleByIdForUser(Long customerId, Long vehicleId) {
        logger.info("Fetching vehicle ID {} for customer ID {}", vehicleId, customerId);

        Vehicle vehicle = this.vehicleRepo.findById(vehicleId)
                .orElseThrow(() -> new RuntimeException("VEHICLE_NOT_FOUND"));

        // Security Check: Ensure the person asking for the car actually owns it
        if (!vehicle.getCustomerId().equals(customerId)) {
            logger.error("Access Denied: Customer {} tried to access Vehicle {}", customerId, vehicleId);
            throw new RuntimeException("ACCESS_DENIED");
        }

        return vehicle;
    }

    public Vehicle registerVehicleForUser(Long customerId, Vehicle vehicle) {
        logger.info("Registering vehicle for customer ID {}", customerId);

        // TEMPORARY: Trusting the customerId blindly for isolation testing.
        // Feign validation will be added back here later.

        if (this.vehicleRepo.existsByVin(vehicle.getVin())) {
            throw new RuntimeException("DUPLICATE_VIN");
        }

        vehicle.setCustomerId(customerId);
        return this.vehicleRepo.save(vehicle);
    }

    public List<Vehicle> getVehiclesForUser(Long customerId) {
        logger.info("Fetching vehicles for customer ID {}", customerId);
        return this.vehicleRepo.findByCustomerId(customerId);
    }

    public Vehicle updateVehicleForUser(Long customerId, Long vehicleId, Vehicle updated) {
        logger.info("Updating vehicle {} for customer ID {}", vehicleId, customerId);
        Vehicle vehicle = this.vehicleRepo.findById(vehicleId)
                .orElseThrow(() -> new RuntimeException("VEHICLE_NOT_FOUND"));

        if (!vehicle.getCustomerId().equals(customerId)) {
            throw new RuntimeException("ACCESS_DENIED");
        }

        vehicle.setModel(updated.getModel());
        vehicle.setYear(updated.getYear());
        vehicle.setStatus(updated.getStatus());
        return this.vehicleRepo.save(vehicle);
    }

    public void deleteVehicleForUser(Long customerId, Long vehicleId) {
        logger.warn("Deleting vehicle {} for customer ID {}", vehicleId, customerId);
        Vehicle vehicle = this.vehicleRepo.findById(vehicleId)
                .orElseThrow(() -> new RuntimeException("VEHICLE_NOT_FOUND"));

        if (!vehicle.getCustomerId().equals(customerId)) {
            throw new RuntimeException("ACCESS_DENIED");
        }
        this.vehicleRepo.delete(vehicle);
    }
}