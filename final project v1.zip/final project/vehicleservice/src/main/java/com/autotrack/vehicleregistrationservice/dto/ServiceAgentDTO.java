package com.autotrack.vehicleregistrationservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ServiceAgentDTO {

    private Long serviceAgentId;

    @NotBlank(message = "Agent name is required")
    private String name;

    @NotNull(message = "Contact number is required")
    private Long contactInfo;

    @NotBlank(message = "Specialization is required")
    private String specialization;
}