package com.autotrack.vehicleregistrationservice.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDTO {

    private Long customerID;

    @NotBlank(message = "Customer name is required")
    private String name;

    @NotNull(message = "Contact number is required")
    private Long contactInfo;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;
}