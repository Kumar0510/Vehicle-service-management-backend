package com.autotrack.vehicleregistrationservice.repository;

import com.autotrack.vehicleregistrationservice.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {

    // Updated from findByCustomerCustomerID to query the ID directly
    List<Vehicle> findByCustomerId(Long customerId);

    boolean existsByVin(String vin);
}