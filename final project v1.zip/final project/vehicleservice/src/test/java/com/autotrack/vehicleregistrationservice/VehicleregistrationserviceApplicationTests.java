package com.autotrack.vehicleregistrationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleregistrationserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
