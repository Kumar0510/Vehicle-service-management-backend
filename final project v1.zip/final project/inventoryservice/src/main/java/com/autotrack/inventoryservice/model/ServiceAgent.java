package com.autotrack.inventoryservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "service_agent")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServiceAgent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long serviceAgentId;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Long contactInfo;

    @Column(nullable = false)
    private String specialization;

    @OneToOne
    @JoinColumn(name = "userId")
    @JsonIgnore
    private User user;

    // REMOVED: serviceRecord list (Managed by Scheduling Service)
}