package com.autotrack.inventoryservice.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "service_part_relations")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServicePartRelation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long relationId;

    // CHANGED: Replaced SparePart object with ID
    @Column(name = "part_id", nullable = false)
    private Long partId;

    @ManyToOne
    @JoinColumn(name = "serviceId")
    private ServiceRecord serviceRecord;

    @Column(name = "quantity_used", nullable = false)
    private Integer quantityUsed;
}