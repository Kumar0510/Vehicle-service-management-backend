//package com.autotrack.invoiceservice.service;
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import static org.mockito.ArgumentMatchers.any;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import static org.mockito.Mockito.doThrow;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.autotrack.invoiceservice.exception.ResourceNotFoundException;
//import com.autotrack.invoiceservice.exception.ServiceRecordException;
//import com.autotrack.invoiceservice.model.Invoice;
//
//@ExtendWith(MockitoExtension.class)
//class ServiceRecordServiceTest {
//
//    @Mock
//    private ServiceRecordRepository serviceRecordRepository;
//
//    @Mock
//    private InvoiceService invoiceService;
//
//    @InjectMocks
//    private ServiceRecordService serviceRecordService;
//
//    private ServiceRecord testServiceRecord;
//    private Vehicle testVehicle;
//    private Customer testCustomer;
//    private Invoice testInvoice;
//
//    @BeforeEach
//    void setUp() {
//        testCustomer = new Customer();
//        testCustomer.setCustomerID(1L);
//        testCustomer.setName("John Doe");
//        testCustomer.setEmail("john@example.com");
//
//        testVehicle = new Vehicle();
//        testVehicle.setVehicleId(1L);
//        testVehicle.setModel("Civic");
//        testVehicle.setYear(2018);
//        testVehicle.setCustomer(testCustomer);
//
//        testServiceRecord = new ServiceRecord();
//        testServiceRecord.setServiceId(1L);
//        testServiceRecord.setServiceType("Brake Replacement");
//        testServiceRecord.setStatus("PENDING");
//        testServiceRecord.setVehicle(testVehicle);
//        testServiceRecord.setServicePartRelation(new ArrayList<>());
//
//        testInvoice = new Invoice();
//        testInvoice.setInvoiceId(1L);
//        testInvoice.setServiceRecord(testServiceRecord);
//        testInvoice.setAmount(150.0);
//        testInvoice.setPaymentStatus("PENDING");
//    }
//
//    @Test
//    void testCreateServiceRecordSuccess() {
//        when(serviceRecordRepository.save(any(ServiceRecord.class))).thenReturn(testServiceRecord);
//
//        ServiceRecord result = serviceRecordService.createServiceRecord(testServiceRecord);
//
//        assertNotNull(result);
//        assertEquals("PENDING", result.getStatus());
//        verify(serviceRecordRepository, times(1)).save(any(ServiceRecord.class));
//    }
//
//    @Test
//    void testCreateServiceRecordWithNullRecord() {
//        assertThrows(ServiceRecordException.class, () -> serviceRecordService.createServiceRecord(null));
//    }
//
//    @Test
//    void testGetAllServiceRecords() {
//        List<ServiceRecord> records = List.of(testServiceRecord);
//        when(serviceRecordRepository.findAll()).thenReturn(records);
//
//        List<ServiceRecord> result = serviceRecordService.getAllServiceRecords();
//
//        assertNotNull(result);
//        assertEquals(1, result.size());
//        verify(serviceRecordRepository, times(1)).findAll();
//    }
//
//    @Test
//    void testGetServiceRecordByIdSuccess() {
//        when(serviceRecordRepository.findById(1L)).thenReturn(Optional.of(testServiceRecord));
//
//        ServiceRecord result = serviceRecordService.getServiceRecordById(1L);
//
//        assertNotNull(result);
//        assertEquals(1L, result.getServiceId());
//        assertEquals("PENDING", result.getStatus());
//        verify(serviceRecordRepository, times(1)).findById(1L);
//    }
//
//    @Test
//    void testGetServiceRecordByIdNotFound() {
//        when(serviceRecordRepository.findById(999L)).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> serviceRecordService.getServiceRecordById(999L));
//    }
//
//    @Test
//    void testGetServiceRecordsByStatus() {
//        List<ServiceRecord> records = List.of(testServiceRecord);
//        when(serviceRecordRepository.findByStatus("PENDING")).thenReturn(records);
//
//        List<ServiceRecord> result = serviceRecordService.getServiceRecordsByStatus("PENDING");
//
//        assertNotNull(result);
//        assertEquals(1, result.size());
//        assertEquals("PENDING", result.get(0).getStatus());
//        verify(serviceRecordRepository, times(1)).findByStatus("PENDING");
//    }
//
//    @Test
//    void testCompleteServiceSuccess() {
//        testServiceRecord.setStatus("PENDING");
//        ServiceRecord completedRecord = new ServiceRecord();
//        completedRecord.setServiceId(1L);
//        completedRecord.setServiceType("Brake Replacement");
//        completedRecord.setStatus("COMPLETED");
//        completedRecord.setCompletionDate(LocalDate.now());
//        completedRecord.setVehicle(testVehicle);
//
//        when(serviceRecordRepository.findById(1L)).thenReturn(Optional.of(testServiceRecord));
//        when(serviceRecordRepository.save(any(ServiceRecord.class))).thenReturn(completedRecord);
//        when(invoiceService.generateInvoice(any(ServiceRecord.class))).thenReturn(testInvoice);
//
//        ServiceRecord result = serviceRecordService.completeService(1L);
//
//        assertNotNull(result);
//        assertEquals("COMPLETED", result.getStatus());
//        assertNotNull(result.getCompletionDate());
//        verify(serviceRecordRepository, times(1)).findById(1L);
//        verify(serviceRecordRepository, times(1)).save(any(ServiceRecord.class));
//        verify(invoiceService, times(1)).generateInvoice(any(ServiceRecord.class));
//    }
//
//    @Test
//    void testCompleteServiceNotFound() {
//        when(serviceRecordRepository.findById(999L)).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> serviceRecordService.completeService(999L));
//    }
//
//    @Test
//    void testCompleteServiceInvoiceGenerationFails() {
//        when(serviceRecordRepository.findById(1L)).thenReturn(Optional.of(testServiceRecord));
//        when(serviceRecordRepository.save(any(ServiceRecord.class))).thenReturn(testServiceRecord);
//        doThrow(new RuntimeException("Invoice generation failed")).when(invoiceService).generateInvoice(any(ServiceRecord.class));
//
//        assertThrows(ServiceRecordException.class, () -> serviceRecordService.completeService(1L));
//    }
//
//    @Test
//    void testGetAllServiceRecordsEmpty() {
//        when(serviceRecordRepository.findAll()).thenReturn(new ArrayList<>());
//
//        List<ServiceRecord> result = serviceRecordService.getAllServiceRecords();
//
//        assertNotNull(result);
//        assertEquals(0, result.size());
//    }
//
//    @Test
//    void testCompleteAlreadyCompletedService() {
//        testServiceRecord.setStatus("COMPLETED");
//        when(serviceRecordRepository.findById(1L)).thenReturn(Optional.of(testServiceRecord));
//        when(serviceRecordRepository.save(any(ServiceRecord.class))).thenReturn(testServiceRecord);
//        when(invoiceService.generateInvoice(any(ServiceRecord.class))).thenReturn(testInvoice);
//
//        ServiceRecord result = serviceRecordService.completeService(1L);
//
//        assertNotNull(result);
//        assertEquals("COMPLETED", result.getStatus());
//        // Should still process and try to generate invoice
//        verify(invoiceService, times(1)).generateInvoice(any(ServiceRecord.class));
//    }
//
//    @Test
//    void testGetServiceRecordsByStatusEmpty() {
//        when(serviceRecordRepository.findByStatus("COMPLETED")).thenReturn(new ArrayList<>());
//
//        List<ServiceRecord> result = serviceRecordService.getServiceRecordsByStatus("COMPLETED");
//
//        assertNotNull(result);
//        assertEquals(0, result.size());
//    }
//
//    @Test
//    void testCreateServiceRecordWithNullVehicle() {
//        testServiceRecord.setVehicle(null);
//        when(serviceRecordRepository.save(any(ServiceRecord.class))).thenReturn(testServiceRecord);
//
//        ServiceRecord result = serviceRecordService.createServiceRecord(testServiceRecord);
//
//        assertNotNull(result);
//        assertEquals("PENDING", result.getStatus());
//        verify(serviceRecordRepository, times(1)).save(any(ServiceRecord.class));
//    }
//}
