//package com.autotrack.invoiceservice.service;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import static org.mockito.ArgumentMatchers.any;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.autotrack.invoiceservice.dto.InvoiceDTO;
//import com.autotrack.invoiceservice.exception.InvalidPaymentStatusException;
//import com.autotrack.invoiceservice.exception.InvoiceGenerationException;
//import com.autotrack.invoiceservice.exception.ResourceNotFoundException;
//import com.autotrack.invoiceservice.model.Invoice;
//import com.autotrack.invoiceservice.repository.InvoiceRepository;
//
//@ExtendWith(MockitoExtension.class)
//class InvoiceServiceTest {
//
//    @Mock
//    private InvoiceRepository invoiceRepository;
//
//    @InjectMocks
//    private InvoiceService invoiceService;
//
//    private Invoice testInvoice;
//    private ServiceRecord testServiceRecord;
//    private Vehicle testVehicle;
//    private Customer testCustomer;
//
//    @BeforeEach
//    void setUp() {
//        testCustomer = new Customer();
//        testCustomer.setCustomerID(1L);
//        testCustomer.setName("John Doe");
//        testCustomer.setEmail("john@example.com");
//
//        testVehicle = new Vehicle();
//        testVehicle.setVehicleId(1L);
//        testVehicle.setModel("Civic");
//        testVehicle.setYear(2018);
//        testVehicle.setCustomer(testCustomer);
//
//        testServiceRecord = new ServiceRecord();
//        testServiceRecord.setServiceId(1L);
//        testServiceRecord.setServiceType("Brake Replacement");
//        testServiceRecord.setStatus("PENDING");
//        testServiceRecord.setVehicle(testVehicle);
//        testServiceRecord.setServicePartRelation(new ArrayList<>());
//
//        testInvoice = new Invoice();
//        testInvoice.setInvoiceId(1L);
//        testInvoice.setAmount(50.0);
//        testInvoice.setPaymentStatus("UNPAID");
//        testInvoice.setServiceRecord(testServiceRecord);
//    }
//
//    @Test
//    void testGenerateInvoiceSuccess() {
//        when(invoiceRepository.save(any(Invoice.class))).thenReturn(testInvoice);
//
//        Invoice result = invoiceService.generateInvoice(testServiceRecord);
//
//        assertNotNull(result);
//        assertEquals(50.0, result.getAmount());
//        assertEquals("UNPAID", result.getPaymentStatus());
//        verify(invoiceRepository, times(1)).save(any(Invoice.class));
//    }
//
//    @Test
//    void testGenerateInvoiceWithNullServiceRecord() {
//        assertThrows(InvoiceGenerationException.class, () -> invoiceService.generateInvoice(null));
//    }
//
//    @Test
//    void testGetAllInvoices() {
//        List<Invoice> invoices = List.of(testInvoice);
//        when(invoiceRepository.findAll()).thenReturn(invoices);
//
//        List<InvoiceDTO> result = invoiceService.getAllInvoices();
//
//        assertNotNull(result);
//        assertEquals(1, result.size());
//        verify(invoiceRepository, times(1)).findAll();
//    }
//
//    @Test
//    void testGetInvoiceByIdSuccess() {
//        when(invoiceRepository.findById(1L)).thenReturn(Optional.of(testInvoice));
//
//        Optional<InvoiceDTO> result = invoiceService.getInvoiceById(1L);
//
//        assertTrue(result.isPresent());
//        assertEquals(1L, result.get().getInvoiceId());
//        verify(invoiceRepository, times(1)).findById(1L);
//    }
//
//    @Test
//    void testGetInvoiceByIdNotFound() {
//        when(invoiceRepository.findById(999L)).thenReturn(Optional.empty());
//
//        Optional<InvoiceDTO> result = invoiceService.getInvoiceById(999L);
//
//        assertFalse(result.isPresent());
//    }
//
//    @Test
//    void testGetInvoicesByPaymentStatus() {
//        List<Invoice> invoices = List.of(testInvoice);
//        when(invoiceRepository.findByPaymentStatus("UNPAID")).thenReturn(invoices);
//
//        List<InvoiceDTO> result = invoiceService.getInvoicesByPaymentStatus("UNPAID");
//
//        assertNotNull(result);
//        assertEquals(1, result.size());
//        assertEquals("UNPAID", result.get(0).getPaymentStatus());
//        verify(invoiceRepository, times(1)).findByPaymentStatus("UNPAID");
//    }
//
//    @Test
//    void testGetInvoicesByServiceId() {
//        List<Invoice> invoices = List.of(testInvoice);
//        when(invoiceRepository.findByServiceId(1L)).thenReturn(invoices);
//
//        List<InvoiceDTO> result = invoiceService.getInvoicesByServiceId(1L);
//
//        assertNotNull(result);
//        assertEquals(1, result.size());
//        verify(invoiceRepository, times(1)).findByServiceId(1L);
//    }
//
//    @Test
//    void testUpdatePaymentStatusSuccess() {
//        Invoice updatedInvoice = new Invoice();
//        updatedInvoice.setInvoiceId(1L);
//        updatedInvoice.setAmount(50.0);
//        updatedInvoice.setPaymentStatus("PAID");
//        updatedInvoice.setServiceRecord(testServiceRecord);
//
//        when(invoiceRepository.findById(1L)).thenReturn(Optional.of(testInvoice));
//        when(invoiceRepository.save(any(Invoice.class))).thenReturn(updatedInvoice);
//
//        InvoiceDTO result = invoiceService.updatePaymentStatus(1L, "PAID");
//
//        assertNotNull(result);
//        assertEquals("PAID", result.getPaymentStatus());
//        verify(invoiceRepository, times(1)).findById(1L);
//        verify(invoiceRepository, times(1)).save(any(Invoice.class));
//    }
//
//    @Test
//    void testUpdatePaymentStatusNotFound() {
//        when(invoiceRepository.findById(999L)).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class, () -> invoiceService.updatePaymentStatus(999L, "PAID"));
//    }
//
//    @Test
//    void testUpdatePaymentStatusWithNullStatus() {
//        assertThrows(InvalidPaymentStatusException.class, () -> invoiceService.updatePaymentStatus(1L, null));
//    }
//
//    @Test
//    void testUpdatePaymentStatusWithBlankStatus() {
//        assertThrows(InvalidPaymentStatusException.class, () -> invoiceService.updatePaymentStatus(1L, "   "));
//    }
//
//    @Test
//    void testGetAllInvoicesEmpty() {
//        when(invoiceRepository.findAll()).thenReturn(new ArrayList<>());
//
//        List<InvoiceDTO> result = invoiceService.getAllInvoices();
//
//        assertNotNull(result);
//        assertEquals(0, result.size());
//        verify(invoiceRepository, times(1)).findAll();
//    }
//
//    @Test
//    void testGenerateInvoiceWithZeroCostParts() {
//        SparePart freePart = new SparePart();
//        freePart.setPartId(1L);
//        freePart.setName("Free Part");
//        freePart.setCost(0.0);
//
//        ServicePartRelation relation = new ServicePartRelation();
//        relation.setRelationId(1L);
//        relation.setSparePart(freePart);
//        relation.setQuantityUsed(5);
//
//        List<ServicePartRelation> parts = new ArrayList<>();
//        parts.add(relation);
//
//        testServiceRecord.setServicePartRelation(parts);
//
//        when(invoiceRepository.save(any(Invoice.class))).thenAnswer(invocation -> invocation.getArgument(0));
//
//        Invoice result = invoiceService.generateInvoice(testServiceRecord);
//
//        assertEquals(50.0, result.getAmount()); // BASE_SERVICE_FEE only
//        verify(invoiceRepository, times(1)).save(any(Invoice.class));
//    }
//
//    @Test
//    void testGenerateInvoiceWithNegativeCostParts() {
//        SparePart negativePart = new SparePart();
//        negativePart.setPartId(1L);
//        negativePart.setName("Negative Part");
//        negativePart.setCost(-10.0);
//
//        ServicePartRelation relation = new ServicePartRelation();
//        relation.setRelationId(1L);
//        relation.setSparePart(negativePart);
//        relation.setQuantityUsed(2);
//
//        List<ServicePartRelation> parts = new ArrayList<>();
//        parts.add(relation);
//
//        testServiceRecord.setServicePartRelation(parts);
//
//        when(invoiceRepository.save(any(Invoice.class))).thenAnswer(invocation -> invocation.getArgument(0));
//
//        Invoice result = invoiceService.generateInvoice(testServiceRecord);
//
//        assertEquals(30.0, result.getAmount()); // BASE_SERVICE_FEE - 20
//        verify(invoiceRepository, times(1)).save(any(Invoice.class));
//    }
//}
