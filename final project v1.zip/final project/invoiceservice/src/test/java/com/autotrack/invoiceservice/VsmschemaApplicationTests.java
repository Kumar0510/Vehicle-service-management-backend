package com.autotrack.invoiceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VsmschemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
