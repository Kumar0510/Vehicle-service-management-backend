//package com.autotrack.invoiceservice.service;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.ArgumentMatchers.*;
//import static org.mockito.Mockito.*;
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.autotrack.invoiceservice.repository.InvoiceRepository;
//
//@ExtendWith(MockitoExtension.class)
//class InvoiceGenerationIntegrationTest {
//
//    @Mock
//    private InvoiceRepository invoiceRepository;
//
//    @Mock
//    private ServiceRecordRepository serviceRecordRepository;
////
//    @InjectMocks
//    private InvoiceService invoiceService;
//
//    private ServiceRecord testServiceRecord;
//    private Vehicle testVehicle;
//    private Customer testCustomer;
//
//    @BeforeEach
//    void setUp() {
//        testCustomer = new Customer();
//        testCustomer.setCustomerID(1L);
//        testCustomer.setName("John Doe");
//        testCustomer.setEmail("john@example.com");
//
//        testVehicle = new Vehicle();
//        testVehicle.setVehicleId(1L);
//        testVehicle.setModel("Civic");
//        testVehicle.setYear(2018);
//        testVehicle.setCustomer(testCustomer);
//
//        testServiceRecord = new ServiceRecord();
//        testServiceRecord.setServiceId(1L);
//        testServiceRecord.setServiceType("Brake Replacement");
//        testServiceRecord.setStatus("PENDING");
//        testServiceRecord.setScheduledDate(LocalDate.now());
//        testServiceRecord.setVehicle(testVehicle);
//    }
//
//    @Test
//    void testInvoiceGenerationWithMultipleSparePartsUsed() {
//        // Setup spare parts
//        SparePart brakePad = new SparePart();
//        brakePad.setPartId(1L);
//        brakePad.setName("Brake Pad");
//        brakePad.setCost(25.0);
//
//        SparePart rotor = new SparePart();
//        rotor.setPartId(2L);
//        rotor.setName("Rotor");
//        rotor.setCost(35.0);
//
//        ServicePartRelation relation1 = new ServicePartRelation();
//        relation1.setRelationId(1L);
//        relation1.setSparePart(brakePad);
//        relation1.setQuantityUsed(2);
//
//        ServicePartRelation relation2 = new ServicePartRelation();
//        relation2.setRelationId(2L);
//        relation2.setSparePart(rotor);
//        relation2.setQuantityUsed(1);
//
//        List<ServicePartRelation> parts = new ArrayList<>();
//        parts.add(relation1);
//        parts.add(relation2);
//
//        testServiceRecord.setServicePartRelation(parts);
//
//        when(invoiceRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));
//
//        var invoice = invoiceService.generateInvoice(testServiceRecord);
//
//        // BASE_SERVICE_FEE (50) + (2 * 25) + (1 * 35) = 50 + 50 + 35 = 135
//        assertEquals(135.0, invoice.getAmount());
//        assertEquals("UNPAID", invoice.getPaymentStatus());
//    }
//
//    @Test
//    void testInvoiceGenerationWithoutSpareParts() {
//        testServiceRecord.setServicePartRelation(new ArrayList<>());
//
//        when(invoiceRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));
//
//        var invoice = invoiceService.generateInvoice(testServiceRecord);
//
//        // BASE_SERVICE_FEE (50) + 0 = 50
//        assertEquals(50.0, invoice.getAmount());
//        assertEquals("UNPAID", invoice.getPaymentStatus());
//    }
//
//    @Test
//    void testInvoiceGenerationWithNullSparePartsList() {
//        testServiceRecord.setServicePartRelation(null);
//
//        when(invoiceRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));
//
//        var invoice = invoiceService.generateInvoice(testServiceRecord);
//
//        // BASE_SERVICE_FEE (50) + 0 = 50
//        assertEquals(50.0, invoice.getAmount());
//        assertEquals("UNPAID", invoice.getPaymentStatus());
//    }
//
//    @Test
//    void testInvoiceCalculationWithExpensiveParts() {
//        SparePart expensivePart = new SparePart();
//        expensivePart.setPartId(1L);
//        expensivePart.setName("Engine Block");
//        expensivePart.setCost(500.0);
//
//        ServicePartRelation relation = new ServicePartRelation();
//        relation.setRelationId(1L);
//        relation.setSparePart(expensivePart);
//        relation.setQuantityUsed(1);
//
//        List<ServicePartRelation> parts = new ArrayList<>();
//        parts.add(relation);
//
//        testServiceRecord.setServicePartRelation(parts);
//
//        when(invoiceRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));
//
//        var invoice = invoiceService.generateInvoice(testServiceRecord);
//
//        // BASE_SERVICE_FEE (50) + (1 * 500) = 550
//        assertEquals(550.0, invoice.getAmount());
//    }
//}
