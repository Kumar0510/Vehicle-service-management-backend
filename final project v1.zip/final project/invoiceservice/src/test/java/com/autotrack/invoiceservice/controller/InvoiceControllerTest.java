package com.autotrack.invoiceservice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.autotrack.invoiceservice.dto.InvoiceDTO;
import com.autotrack.invoiceservice.exception.GlobalExceptionHandler;
import com.autotrack.invoiceservice.exception.InvalidPaymentStatusException;
import com.autotrack.invoiceservice.exception.ResourceNotFoundException;
import com.autotrack.invoiceservice.service.InvoiceService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class InvoiceControllerTest {

    @Mock
    private InvoiceService invoiceService;

    @InjectMocks
    private InvoiceController invoiceController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;
    private InvoiceDTO testInvoiceDTO;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(invoiceController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
        objectMapper = new ObjectMapper();

        testInvoiceDTO = new InvoiceDTO();
        testInvoiceDTO.setInvoiceId(1L);
        testInvoiceDTO.setAmount(50.0);
        testInvoiceDTO.setPaymentStatus("UNPAID");
        testInvoiceDTO.setServiceId(1L);
        testInvoiceDTO.setServiceType("Brake Replacement");
        testInvoiceDTO.setVehicleDetails("2018 Civic");
        testInvoiceDTO.setCustomerName("John Doe");
    }

    @Test
    void testGetAllInvoices() throws Exception {
        List<InvoiceDTO> invoices = List.of(testInvoiceDTO);
        when(invoiceService.getAllInvoices()).thenReturn(invoices);

        mockMvc.perform(get("/api/invoices")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].invoiceId", is(1)))
                .andExpect(jsonPath("$[0].amount", is(50.0)))
                .andExpect(jsonPath("$[0].paymentStatus", is("UNPAID")));

        verify(invoiceService, times(1)).getAllInvoices();
    }

    @Test
    void testGetInvoiceByIdSuccess() throws Exception {
        when(invoiceService.getInvoiceById(1L)).thenReturn(Optional.of(testInvoiceDTO));

        mockMvc.perform(get("/api/invoices/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.invoiceId", is(1)))
                .andExpect(jsonPath("$.amount", is(50.0)))
                .andExpect(jsonPath("$.customerName", is("John Doe")));

        verify(invoiceService, times(1)).getInvoiceById(1L);
    }

    @Test
    void testGetInvoiceByIdNotFound() throws Exception {
        when(invoiceService.getInvoiceById(999L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/invoices/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(invoiceService, times(1)).getInvoiceById(999L);
    }

    @Test
    void testGetInvoicesByStatus() throws Exception {
        List<InvoiceDTO> invoices = List.of(testInvoiceDTO);
        when(invoiceService.getInvoicesByPaymentStatus("UNPAID")).thenReturn(invoices);

        mockMvc.perform(get("/api/invoices/status/UNPAID")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].paymentStatus", is("UNPAID")));

        verify(invoiceService, times(1)).getInvoicesByPaymentStatus("UNPAID");
    }

    @Test
    void testGetInvoicesByServiceId() throws Exception {
        List<InvoiceDTO> invoices = List.of(testInvoiceDTO);
        when(invoiceService.getInvoicesByServiceId(1L)).thenReturn(invoices);

        mockMvc.perform(get("/api/invoices/service/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].serviceId", is(1)));

        verify(invoiceService, times(1)).getInvoicesByServiceId(1L);
    }

    @Test
    void testUpdatePaymentStatusSuccess() throws Exception {
        testInvoiceDTO.setPaymentStatus("PAID");
        when(invoiceService.updatePaymentStatus(1L, "PAID")).thenReturn(testInvoiceDTO);

        mockMvc.perform(put("/api/invoices/1/status?status=PAID")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.invoiceId", is(1)))
                .andExpect(jsonPath("$.paymentStatus", is("PAID")));

        verify(invoiceService, times(1)).updatePaymentStatus(1L, "PAID");
    }

    @Test
    void testUpdatePaymentStatusNotFound() throws Exception {
        when(invoiceService.updatePaymentStatus(999L, "PAID"))
                .thenThrow(new ResourceNotFoundException("Invoice not found for id: 999"));

        mockMvc.perform(put("/api/invoices/999/status?status=PAID")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message", containsString("not found")));

        verify(invoiceService, times(1)).updatePaymentStatus(999L, "PAID");
    }

    @Test
    void testGetAllInvoicesEmpty() throws Exception {
        when(invoiceService.getAllInvoices()).thenReturn(new ArrayList<>());

        mockMvc.perform(get("/api/invoices")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));

        verify(invoiceService, times(1)).getAllInvoices();
    }

    @Test
    void testGenerateInvoiceEndpoint() throws Exception {
        mockMvc.perform(post("/api/invoices/generate/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testUpdatePaymentStatusWithInvalidStatus() throws Exception {
        when(invoiceService.updatePaymentStatus(1L, ""))
                .thenThrow(new InvalidPaymentStatusException("Payment status must not be empty."));

        mockMvc.perform(put("/api/invoices/1/status?status=")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("must not be empty")));

        verify(invoiceService, times(1)).updatePaymentStatus(1L, "");
    }

    @Test
    void testGetInvoicesByStatusWithNoResults() throws Exception {
        when(invoiceService.getInvoicesByPaymentStatus("CANCELLED")).thenReturn(new ArrayList<>());

        mockMvc.perform(get("/api/invoices/status/CANCELLED")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));

        verify(invoiceService, times(1)).getInvoicesByPaymentStatus("CANCELLED");
    }
}
