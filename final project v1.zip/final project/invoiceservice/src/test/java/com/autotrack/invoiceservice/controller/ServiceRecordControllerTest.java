package com.autotrack.invoiceservice.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.autotrack.invoiceservice.exception.GlobalExceptionHandler;
import com.autotrack.invoiceservice.exception.ResourceNotFoundException;
import com.autotrack.invoiceservice.exception.ServiceRecordException;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class ServiceRecordControllerTest {

    @Mock
    private ServiceRecordService serviceRecordService;

    @InjectMocks
    private ServiceRecordController serviceRecordController;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;
    private ServiceRecord testServiceRecord;
    private Vehicle testVehicle;
    private Customer testCustomer;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(serviceRecordController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule());

        testCustomer = new Customer();
        testCustomer.setCustomerID(1L);
        testCustomer.setName("John Doe");
        testCustomer.setEmail("john@example.com");

        testVehicle = new Vehicle();
        testVehicle.setVehicleId(1L);
        testVehicle.setModel("Civic");
        testVehicle.setYear(2018);
        testVehicle.setCustomer(testCustomer);

        testServiceRecord = new ServiceRecord();
        testServiceRecord.setServiceId(1L);
        testServiceRecord.setServiceType("Brake Replacement");
        testServiceRecord.setStatus("PENDING");
        testServiceRecord.setScheduledDate(LocalDate.now().plusDays(1));
        testServiceRecord.setVehicle(testVehicle);
    }

    @Test
    void testCreateServiceRecordSuccess() throws Exception {
        when(serviceRecordService.createServiceRecord(org.mockito.ArgumentMatchers.any(ServiceRecord.class)))
                .thenReturn(testServiceRecord);

        mockMvc.perform(post("/api/service-records")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testServiceRecord)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.serviceId", is(1)))
                .andExpect(jsonPath("$.status", is("PENDING")))
                .andExpect(jsonPath("$.serviceType", is("Brake Replacement")));

        verify(serviceRecordService, times(1)).createServiceRecord(org.mockito.ArgumentMatchers.any(ServiceRecord.class));
    }

    @Test
    void testGetAllServiceRecords() throws Exception {
        List<ServiceRecord> records = List.of(testServiceRecord);
        when(serviceRecordService.getAllServiceRecords()).thenReturn(records);

        mockMvc.perform(get("/api/service-records")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].serviceId", is(1)))
                .andExpect(jsonPath("$[0].status", is("PENDING")));

        verify(serviceRecordService, times(1)).getAllServiceRecords();
    }

    @Test
    void testGetServiceRecordByIdSuccess() throws Exception {
        when(serviceRecordService.getServiceRecordById(1L)).thenReturn(testServiceRecord);

        mockMvc.perform(get("/api/service-records/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.serviceId", is(1)))
                .andExpect(jsonPath("$.serviceType", is("Brake Replacement")))
                .andExpect(jsonPath("$.status", is("PENDING")));

        verify(serviceRecordService, times(1)).getServiceRecordById(1L);
    }

    @Test
    void testGetServiceRecordByIdNotFound() throws Exception {
        when(serviceRecordService.getServiceRecordById(999L))
                .thenThrow(new ResourceNotFoundException("Service record not found for id: 999"));

        mockMvc.perform(get("/api/service-records/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message", containsString("not found")));

        verify(serviceRecordService, times(1)).getServiceRecordById(999L);
    }

    @Test
    void testGetServiceRecordsByStatus() throws Exception {
        List<ServiceRecord> records = List.of(testServiceRecord);
        when(serviceRecordService.getServiceRecordsByStatus("PENDING")).thenReturn(records);

        mockMvc.perform(get("/api/service-records/status/PENDING")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].status", is("PENDING")));

        verify(serviceRecordService, times(1)).getServiceRecordsByStatus("PENDING");
    }

    @Test
    void testCompleteServiceSuccess() throws Exception {
        testServiceRecord.setStatus("COMPLETED");
        testServiceRecord.setCompletionDate(LocalDate.now());

        when(serviceRecordService.completeService(1L)).thenReturn(testServiceRecord);

        mockMvc.perform(put("/api/service-records/1/complete")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.serviceId", is(1)))
                .andExpect(jsonPath("$.status", is("COMPLETED")))
                .andExpect(jsonPath("$.completionDate", notNullValue()));

        verify(serviceRecordService, times(1)).completeService(1L);
    }

    @Test
    void testCompleteServiceNotFound() throws Exception {
        when(serviceRecordService.completeService(999L))
                .thenThrow(new ResourceNotFoundException("Service record not found for id: 999"));

        mockMvc.perform(put("/api/service-records/999/complete")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message", containsString("not found")));

        verify(serviceRecordService, times(1)).completeService(999L);
    }

    @Test
    void testGetAllServiceRecordsEmpty() throws Exception {
        when(serviceRecordService.getAllServiceRecords()).thenReturn(new ArrayList<>());

        mockMvc.perform(get("/api/service-records")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));

        verify(serviceRecordService, times(1)).getAllServiceRecords();
    }

    @Test
    void testGetServiceRecordsByStatusEmpty() throws Exception {
        when(serviceRecordService.getServiceRecordsByStatus("COMPLETED")).thenReturn(new ArrayList<>());

        mockMvc.perform(get("/api/service-records/status/COMPLETED")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(0)));

        verify(serviceRecordService, times(1)).getServiceRecordsByStatus("COMPLETED");
    }

    @Test
    void testCreateServiceRecordWithInvalidData() throws Exception {
        when(serviceRecordService.createServiceRecord(org.mockito.ArgumentMatchers.any(ServiceRecord.class)))
                .thenThrow(new ServiceRecordException("Service record payload must not be null."));

        mockMvc.perform(post("/api/service-records")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("must not be null")));

        verify(serviceRecordService, times(1)).createServiceRecord(org.mockito.ArgumentMatchers.any(ServiceRecord.class));
    }

    @Test
    void testCompleteServiceWithInvoiceGenerationFailure() throws Exception {
        when(serviceRecordService.completeService(1L))
                .thenThrow(new ServiceRecordException("Could not generate invoice for service record 1"));

        mockMvc.perform(put("/api/service-records/1/complete")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message", containsString("Could not generate invoice")));

        verify(serviceRecordService, times(1)).completeService(1L);
    }
}
