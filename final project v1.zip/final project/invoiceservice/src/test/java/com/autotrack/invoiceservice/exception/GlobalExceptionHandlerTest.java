package com.autotrack.invoiceservice.exception;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(new TestController())
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    void testResourceNotFoundExceptionHandling() throws Exception {
        mockMvc.perform(get("/test/not-found")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status", is(404)))
                .andExpect(jsonPath("$.error", is("Not Found")))
                .andExpect(jsonPath("$.message", containsString("Resource not found")));
    }

    @Test
    void testInvoiceGenerationExceptionHandling() throws Exception {
        mockMvc.perform(get("/test/invoice-generation-error")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status", is(400)))
                .andExpect(jsonPath("$.error", is("Bad Request")))
                .andExpect(jsonPath("$.message", containsString("Invoice generation")));
    }

    @Test
    void testInvalidPaymentStatusExceptionHandling() throws Exception {
        mockMvc.perform(get("/test/invalid-status")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status", is(400)))
                .andExpect(jsonPath("$.error", is("Bad Request")))
                .andExpect(jsonPath("$.message", containsString("Invalid status")));
    }

    @Test
    void testServiceRecordExceptionHandling() throws Exception {
        mockMvc.perform(get("/test/service-record-error")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status", is(400)))
                .andExpect(jsonPath("$.error", is("Bad Request")))
                .andExpect(jsonPath("$.message", containsString("Service record")));
    }

    @Test
    void testGenericExceptionHandling() throws Exception {
        mockMvc.perform(get("/test/generic-error")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.status", is(500)))
                .andExpect(jsonPath("$.error", is("Internal Server Error")))
                .andExpect(jsonPath("$.message", is("An unexpected error occurred.")));
    }

    @RestController
    static class TestController {
        @GetMapping("/test/not-found")
        public void testNotFound() {
            throw new ResourceNotFoundException("Resource not found");
        }

        @GetMapping("/test/invoice-generation-error")
        public void testInvoiceGenerationError() {
            throw new InvoiceGenerationException("Invoice generation failed");
        }

        @GetMapping("/test/invalid-status")
        public void testInvalidStatus() {
            throw new InvalidPaymentStatusException("Invalid status provided");
        }

        @GetMapping("/test/service-record-error")
        public void testServiceRecordError() {
            throw new ServiceRecordException("Service record operation failed");
        }

        @GetMapping("/test/generic-error")
        public void testGenericError() {
            throw new RuntimeException("Unexpected error");
        }
    }
}
