package com.autotrack.invoiceservice.dto;

import lombok.Data;
import java.time.LocalDate;
import java.util.List;

@Data
public class ServiceFullDetailsDTO {
    private Long serviceId;
    private String serviceType;
    private LocalDate scheduledDate;
    private LocalDate completionDate;
    private String status;
    private Long vehicleId;
    private String vehicleModel;
    private String vehicleVin;
    private Long agentId;
    private String agentName;
    private List<PartsDTO> partsList; // We need this nested DTO below
}