//package com.autotrack.invoiceservice.client;
//
//import com.autotrack.invoiceservice.dto.ServicePartRelationDTO;
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import java.util.List;
//
//@FeignClient(name = "servicescheduling")
//public interface ServicePartRelationClient {
//
//    @GetMapping("/service/{id}")
//    List<ServicePartRelationDTO> getRelationsByServiceId(@PathVariable long id);
//}
