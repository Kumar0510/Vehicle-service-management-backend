package com.autotrack.invoiceservice.dto;

import lombok.Data;

@Data
public class ServicePartRelationDTO {
    private Long relationId;
    private Long serviceId;
    private Long partId;
    private int quantityUsed;
}