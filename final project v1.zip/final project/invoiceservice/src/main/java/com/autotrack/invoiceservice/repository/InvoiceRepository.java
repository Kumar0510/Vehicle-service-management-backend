package com.autotrack.invoiceservice.repository;

import com.autotrack.invoiceservice.model.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    List<Invoice> findByPaymentStatus(String paymentStatus);
    List<Invoice> findByServiceId(Long serviceId);
}