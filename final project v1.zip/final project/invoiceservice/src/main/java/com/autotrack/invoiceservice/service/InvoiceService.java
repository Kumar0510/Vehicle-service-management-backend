package com.autotrack.invoiceservice.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.autotrack.invoiceservice.client.ServiceRecordClient;
import com.autotrack.invoiceservice.client.SparePartClient;
import com.autotrack.invoiceservice.dto.ServiceFullDetailsDTO;
import com.autotrack.invoiceservice.dto.SparePartDTO;
import com.autotrack.invoiceservice.dto.PartsDTO;
import com.autotrack.invoiceservice.dto.InvoiceDTO;
import com.autotrack.invoiceservice.exception.InvalidPaymentStatusException;
import com.autotrack.invoiceservice.exception.ResourceNotFoundException;
import com.autotrack.invoiceservice.model.Invoice;
import com.autotrack.invoiceservice.repository.InvoiceRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService {

    private static final Logger logger = LoggerFactory.getLogger(InvoiceService.class);

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private SparePartClient spareClient;

    @Autowired
    private ServiceRecordClient schedulingClient;

    public InvoiceDTO generateInvoice(Long serviceId, Long userId) {
        logger.info("Initiating real-time invoice generation for service ID: {}", serviceId);

        List<Invoice> existingInvoices = invoiceRepository.findByServiceId(serviceId);
        if (!existingInvoices.isEmpty()) {
            logger.warn("Invoice already exists for service ID: {}. Returning existing record.", serviceId);
            return convertToDTO(existingInvoices.get(0));
        }

        // 1. Fetch unified data from Scheduling Service
        ServiceFullDetailsDTO serviceDetails = schedulingClient.getFullDetails(userId, serviceId);

        // 2. Dynamic Labor Fee Calculation
        double laborFee = calculateLaborFee(serviceDetails.getServiceType());

        // 3. Parts Cost Calculation
        double totalPartsCost = 0.0;
        if (serviceDetails.getPartsList() != null && !serviceDetails.getPartsList().isEmpty()) {

            // Map from the garage DTO (PartsDTO)
            List<Long> partIds = serviceDetails.getPartsList().stream()
                    .map(PartsDTO::getPartId)
                    .distinct()
                    .toList();

            // Fetch pricing from the catalog DTO (SparePartDTO)
            List<SparePartDTO> sparePartsList = spareClient.getSpareParts(partIds);

            Map<Long, Double> priceMap = sparePartsList.stream()
                    .collect(Collectors.toMap(SparePartDTO::getPartId, SparePartDTO::getCost));

            // Iterate over the garage DTO to calculate totals securely
            for (PartsDTO part : serviceDetails.getPartsList()) {
                Double unitPrice = priceMap.get(part.getPartId());
                if (unitPrice != null) {
                    double subTotal = unitPrice * part.getQuantityUsed();
                    totalPartsCost += subTotal;
                    logger.info("Part ID {}: {} x ${} = ${}",
                            part.getPartId(), part.getQuantityUsed(), unitPrice, subTotal);
                } else {
                    logger.error("Price not found for Part ID: {}", part.getPartId());
                }
            }
        }

        // 4. Final Aggregation
        double finalAmount = laborFee + totalPartsCost;

        Invoice invoice = new Invoice();
        invoice.setAmount(finalAmount);
        invoice.setPaymentStatus("UNPAID");
        invoice.setServiceId(serviceId);

        Invoice saved = invoiceRepository.save(invoice);
        logger.info("Invoice generated successfully with total amount: ${}", finalAmount);

        // --- THE HYDRATION FIX ---
        // Format the vehicle string nicely for the receipt
        String vehicleString = serviceDetails.getVehicleModel() + " (VIN: " + serviceDetails.getVehicleVin() + ")";

        // Placeholder until we integrate the API Gateway/Auth Service
        long customerId = userId;

        // Return the fully populated DTO to the frontend
        return new InvoiceDTO(
                saved.getInvoiceId(),
                saved.getAmount(),
                saved.getPaymentStatus(),
                saved.getServiceId(),
                serviceDetails.getServiceType(), // Hydrated!
                vehicleString,                   // Hydrated!
                customerId               // Placeholder
        );
    }

    private double calculateLaborFee(String serviceType) {
        if (serviceType == null) return 50.0;

        return switch (serviceType.toLowerCase()) {
            case "standard oil change" -> 25.0;
            case "brake replacement" -> 150.0;
            case "engine swap" -> 800.0;
            default -> 50.0; // Default flat rate for unknown services
        };
    }

    public List<InvoiceDTO> getAllInvoices() {
        logger.info("Fetching all invoices");
        return invoiceRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public Optional<InvoiceDTO> getInvoiceById(Long id) {
        logger.debug("Fetching invoice by id {}", id);
        return invoiceRepository.findById(id).map(this::convertToDTO);
    }

    public List<InvoiceDTO> getInvoicesByPaymentStatus(String status) {
        logger.debug("Fetching invoices by payment status {}", status);
        return invoiceRepository.findByPaymentStatus(status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<InvoiceDTO> getInvoicesByServiceId(Long serviceId) {
        logger.debug("Fetching invoices by service id {}", serviceId);
        return invoiceRepository.findByServiceId(serviceId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public InvoiceDTO updatePaymentStatus(Long invoiceId, String status) {
        logger.info("Updating payment status for invoice {} to {}", invoiceId, status);
        if (status == null || status.isBlank()) {
            logger.error("Invalid payment status for invoice {}: {}", invoiceId, status);
            throw new InvalidPaymentStatusException("Payment status must not be empty.");
        }

        Optional<Invoice> invoiceOpt = invoiceRepository.findById(invoiceId);
        if (invoiceOpt.isPresent()) {
            Invoice invoice = invoiceOpt.get();
            invoice.setPaymentStatus(status);
            Invoice saved = invoiceRepository.save(invoice);
            logger.info("Successfully updated payment status to {} for invoice {}", status, invoiceId);
            return convertToDTO(saved);
        }

        logger.warn("Invoice not found for id {} when updating payment status", invoiceId);
        throw new ResourceNotFoundException("Invoice not found for id: " + invoiceId);
    }

    private InvoiceDTO convertToDTO(Invoice invoice) {
        return new InvoiceDTO(
                invoice.getInvoiceId(),
                invoice.getAmount(),
                invoice.getPaymentStatus(),
                invoice.getServiceId(),
                null,
                null,
                null
        );
    }
}