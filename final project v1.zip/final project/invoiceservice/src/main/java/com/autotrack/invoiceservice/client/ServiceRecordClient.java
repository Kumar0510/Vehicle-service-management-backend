package com.autotrack.invoiceservice.client;

import com.autotrack.invoiceservice.dto.ServiceFullDetailsDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "servicescheduling")
public interface ServiceRecordClient {

    @GetMapping("/api/serviceRecord/details/{serviceId}")
    ServiceFullDetailsDTO getFullDetails(
            @RequestHeader("X-USER-ID") Long userId,
            @PathVariable("serviceId") Long serviceId);
}