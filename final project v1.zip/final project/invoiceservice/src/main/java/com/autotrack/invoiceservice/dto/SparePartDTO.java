package com.autotrack.invoiceservice.dto;

import lombok.Data;

@Data
public class SparePartDTO {
    private Long partId;
    private String name;
    private double cost;
}