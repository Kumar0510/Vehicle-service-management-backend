package com.autotrack.invoiceservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceDTO {

    // --- Data Owned by Invoice Service ---
    private Long invoiceId;
    private double amount;
    private String paymentStatus;

    // --- The Decoupled Link ---
    private Long serviceId;

//    // --- Aggregated Data (To be filled by Feign Clients later) ---
    private String serviceType;    // Will be fetched from Scheduling Service
    private String vehicleDetails; // Will be fetched from Registration Service
    private Long customerId;   // Will be fetched from Auth Service
}