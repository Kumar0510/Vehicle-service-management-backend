package com.autotrack.invoiceservice.controller;

import com.autotrack.invoiceservice.client.SparePartClient;
import com.autotrack.invoiceservice.dto.InvoiceDTO;
import com.autotrack.invoiceservice.dto.SparePartDTO;
import com.autotrack.invoiceservice.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    private static final Logger logger = LoggerFactory.getLogger(InvoiceController.class);

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private SparePartClient spareClient;

    @GetMapping("/bulk-spareparts")
    public List<SparePartDTO> getSpareParts(@RequestParam("ids") List<Long> partIds){
        return spareClient.getSpareParts(partIds);
    }

    @GetMapping
    public List<InvoiceDTO> getAllInvoices() {
        logger.info("Request received: get all invoices");
        return invoiceService.getAllInvoices();
    }

    @GetMapping("/{id}")
    public ResponseEntity<InvoiceDTO> getInvoiceById(@PathVariable Long id) {
        logger.info("Request received: get invoice by id {}", id);
        Optional<InvoiceDTO> invoice = invoiceService.getInvoiceById(id);
        return invoice.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/status/{status}")
    public List<InvoiceDTO> getInvoicesByStatus(@PathVariable String status) {
        logger.info("Request received: get invoices with status {}", status);
        return invoiceService.getInvoicesByPaymentStatus(status);
    }

    @GetMapping("/service/{serviceId}")
    public List<InvoiceDTO> getInvoicesByServiceId(@PathVariable Long serviceId) {
        logger.info("Request received: get invoices for service {}", serviceId);
        return invoiceService.getInvoicesByServiceId(serviceId);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<InvoiceDTO> updatePaymentStatus(@PathVariable Long id, @RequestParam String status) {
        logger.info("Request received: update invoice {} payment status to {}", id, status);
        InvoiceDTO updatedInvoice = invoiceService.updatePaymentStatus(id, status);
        return ResponseEntity.ok(updatedInvoice);
    }

    @PostMapping("/generate/{serviceId}")
    public ResponseEntity<InvoiceDTO> generateInvoice(
            @RequestHeader("X-USER-ID") Long customerId,
            @PathVariable Long serviceId) {

        logger.info("Request received: Generate Invoice for requested Service ID: {}", serviceId);
        return ResponseEntity.ok(invoiceService.generateInvoice(serviceId, customerId));
    }
}