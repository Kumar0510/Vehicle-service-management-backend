package com.autotrack.invoiceservice.exception;

public class ServiceRecordException extends RuntimeException {

    public ServiceRecordException(String message) {
        super(message);
    }

    public ServiceRecordException(String message, Throwable cause) {
        super(message, cause);
    }
}
