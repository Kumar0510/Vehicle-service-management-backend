package com.autotrack.invoiceservice.client;

import com.autotrack.invoiceservice.dto.SparePartDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Component
@FeignClient(name = "inventoryservice")
public interface SparePartClient {

    @GetMapping("/api/inventoryservice/spare-parts/{id}")
    SparePartDTO getSparePartById();

    @GetMapping("/api/inventoryservice/spare-parts/bulk-fetch")
    List<SparePartDTO> getSpareParts(@RequestParam("ids") List<Long> parts);
}
