package com.autotrack.auth.service;

import com.autotrack.auth.dto.ServiceAgentApprovalRequest;
import com.autotrack.auth.exception.UserNotFoundException;
import com.autotrack.auth.model.User;
import com.autotrack.auth.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    private static final Logger logger = LoggerFactory.getLogger(AdminService.class);
    private final UserRepository userRepository;

    public AdminService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public String approveServiceAgent(ServiceAgentApprovalRequest request) {
        logger.info("Processing approval for userId: {}", request.getUserId());

        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> {
                    logger.error("User not found with id: {}", request.getUserId());
                    return new UserNotFoundException("User not found");
                });

        if (!"SERVICE_AGENT".equalsIgnoreCase(user.getRole())) {
            logger.error("User {} is not a Service Agent", request.getUserId());
            throw new RuntimeException("User is not a Service Agent");
        }

        if (request.isApproved()) {
            user.setStatus("VERIFIED");
            userRepository.save(user);
            logger.info("Service Agent {} approved", request.getUserId());
            return "Service Agent approved.";
        } else {
            user.setStatus("DENIED");
            userRepository.save(user);
            logger.info("Service Agent {} denied", request.getUserId());
            return "Service Agent denied.";
        }
    }
}
