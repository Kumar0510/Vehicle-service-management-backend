package com.autotrack.auth.service;

import com.autotrack.auth.model.ServiceAgent;
import com.autotrack.auth.repository.ServiceAgentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ServiceAgentService {

    private final ServiceAgentRepository serviceAgentRepository;

    /**
     * Finds the Service Agent ID based on the associated User's username.
     * This assumes your ServiceAgent model has a 'user' relationship 
     * or a 'username' field.
     */
    public Long findAgentIdByUsername(String username) {
        return serviceAgentRepository.findAll().stream()
                .filter(agent -> agent.getUser().getUserName().equals(username))
                .map(ServiceAgent::getServiceAgentId)
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Service Agent profile not found for user: " + username));
    }
}