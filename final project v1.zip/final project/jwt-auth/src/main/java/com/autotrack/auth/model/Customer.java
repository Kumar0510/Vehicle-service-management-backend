package com.autotrack.auth.model;

import com.autotrack.auth.model.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "customer")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerId;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Long contactInfo;

    @Column(nullable = false)
    private String email;

    @OneToOne
    @JoinColumn(name = "userId")
    @JsonIgnore
    private User user;

    // REMOVED: vehicleList (Managed by Registration Service)
}