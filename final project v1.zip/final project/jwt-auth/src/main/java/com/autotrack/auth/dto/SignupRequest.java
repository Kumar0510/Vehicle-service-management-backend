package com.autotrack.auth.dto;

import lombok.Getter;
import lombok.Setter;
import jakarta.validation.constraints.*;

@Getter
@Setter
public class SignupRequest {
    @NotBlank(message = "Username is required")
    private String userName;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    @NotBlank(message = "Role is required")
    private String role; // CUSTOMER or SERVICE_AGENT

    @NotBlank(message = "Name is required")
    private String name;

    @NotNull(message = "Contact info is required")
    @Digits(integer = 10, fraction = 0, message = "Contact info must be a 10-digit number")
    private Long contactInfo;

    private String specialization; // only for ServiceAgent

    @Email(message = "Invalid email format")
    private String email; // only for Customer
}
