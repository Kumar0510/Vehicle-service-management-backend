package com.autotrack.auth.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);

    private final String secretKey = "ce0c009ceb2f3aaeee297a862ba4ebb67b62e6dd896ee993206acc53ee7d1b67"; // use env variable in production
    private final long expirationMs = 3600000; // 1 hour

    private Key getSigningKey() {
        byte[] keyBytes = this.secretKey.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public String generateToken(String username, String role, String status) {
        logger.debug("Generating token for user: {}, role: {}, status: {}", username, role, status);
        return Jwts.builder()
                .setSubject(username)
                .claim("role", role)
                .claim("status", status)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(SignatureAlgorithm.HS256, getSigningKey())
                .compact();
    }

    public Claims extractClaims(String token) {
        logger.debug("Extracting claims from token");
        return Jwts.parser()
                .setSigningKey(getSigningKey())
                .parseClaimsJws(token)
                .getBody();
    }

    public boolean validateToken(String token, String username) {
        logger.debug("Validating token for user: {}", username);
        String tokenUser = extractClaims(token).getSubject();
        boolean valid = (tokenUser.equals(username) && !isTokenExpired(token));
        if (valid) {
            logger.info("Token validated successfully for user: {}", username);
        } else {
            logger.warn("Token validation failed for user: {}", username);
        }
        return valid;
    }

    private boolean isTokenExpired(String token) {
        boolean expired = extractClaims(token).getExpiration().before(new Date());
        if (expired) {
            logger.warn("Token expired");
        }
        return expired;
    }
}
