package com.autotrack.auth.controller;

import com.autotrack.auth.config.JwtUtil;
import com.autotrack.auth.service.ServiceAgentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.*;
import com.autotrack.auth.dto.LoginRequest;
import com.autotrack.auth.dto.LoginResponse;
import com.autotrack.auth.dto.SignupRequest;
import com.autotrack.auth.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
    private final AuthService authService;


    @Autowired
    private ServiceAgentService agentService;

    @Autowired
    private JwtUtil jwtUtil;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/signup")
    public ResponseEntity<String> signup(@Valid @RequestBody SignupRequest request) {
        logger.info("Signup request received for user: {}", request.getUserName());
        String result = authService.signup(request);
        logger.info("Signup result: {}", result);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        logger.info("Login attempt for user: {}", request.getUserName());
        LoginResponse response = authService.login(request);
        logger.info("Login successful for user: {}", request.getUserName());
        return ResponseEntity.ok(response);
    }


    @GetMapping("/get-agent")
    public ResponseEntity<?> getAgentDetails(@RequestHeader("Authorization") String authHeader) {
        // 1. Extract token and username
        String token = authHeader.substring(7);
        String username = jwtUtil.extractClaims(token).getSubject();

        // 2. Fetch the specific Agent ID linked to this user
        Long agentId = agentService.findAgentIdByUsername(username);

        // 3. Return the ID so the frontend can use it for Scheduling
        return ResponseEntity.ok(java.util.Map.of("serviceAgentId", agentId));
    }

}
