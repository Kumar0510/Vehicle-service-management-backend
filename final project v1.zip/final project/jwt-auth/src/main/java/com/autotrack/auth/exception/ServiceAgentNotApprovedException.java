package com.autotrack.auth.exception;

public class ServiceAgentNotApprovedException extends RuntimeException {
    public ServiceAgentNotApprovedException(String message) {
        super(message);
    }
}
