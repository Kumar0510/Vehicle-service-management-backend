package com.autotrack.auth.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ServiceAgentApprovalRequest {
    @NotNull(message = "UserId is required")
    private Long userId;
    private boolean approved;
}

