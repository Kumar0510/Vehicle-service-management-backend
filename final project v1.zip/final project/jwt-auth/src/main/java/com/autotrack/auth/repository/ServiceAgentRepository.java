package com.autotrack.auth.repository;

import com.autotrack.auth.model.ServiceAgent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceAgentRepository extends JpaRepository<ServiceAgent, Long> {
}
