package com.autotrack.auth.controller;

import jakarta.validation.*;
import com.autotrack.auth.dto.ServiceAgentApprovalRequest;
import com.autotrack.auth.service.AdminService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @PostMapping("/approve")
    public String approveServiceAgent(@Valid @RequestBody ServiceAgentApprovalRequest request) {
        logger.info("Approval request received for userId: {}", request.getUserId());
        String result = adminService.approveServiceAgent(request);
        logger.info("Approval result for userId {}: {}", request.getUserId(), result);
        return result;
    }

}
