package com.autotrack.auth.service;

import com.autotrack.auth.dto.SignupRequest;
import com.autotrack.auth.dto.LoginRequest;
import com.autotrack.auth.dto.LoginResponse;
import com.autotrack.auth.exception.InvalidCredentialsException;
import com.autotrack.auth.exception.ServiceAgentNotApprovedException;
import com.autotrack.auth.exception.UserNotFoundException;
import com.autotrack.auth.model.Customer;
import com.autotrack.auth.model.ServiceAgent;
import com.autotrack.auth.model.User;
import com.autotrack.auth.repository.UserRepository;
import com.autotrack.auth.repository.CustomerRepository;
import com.autotrack.auth.repository.ServiceAgentRepository;
import com.autotrack.auth.config.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private static final Logger logger = LoggerFactory.getLogger(AuthService.class);

    private final UserRepository userRepository;
    private final CustomerRepository customerRepository;
    private final ServiceAgentRepository serviceAgentRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    // 1. Declare the AuthenticationManager
    private final AuthenticationManager authenticationManager;

    // 2. Inject it via the constructor
    public AuthService(UserRepository userRepository,
                       CustomerRepository customerRepository,
                       ServiceAgentRepository serviceAgentRepository,
                       PasswordEncoder passwordEncoder,
                       JwtUtil jwtUtil,
                       AuthenticationManager authenticationManager) {
        this.userRepository = userRepository;
        this.customerRepository = customerRepository;
        this.serviceAgentRepository = serviceAgentRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
        this.authenticationManager = authenticationManager;
    }

    // 3. CRITICAL: Added @Transactional to prevent database corruption if customer/agent save fails
    @Transactional
    public String signup(SignupRequest request) {
        logger.info("Signup initiated for user: {}", request.getUserName());
        User user = new User();
        user.setUserName(request.getUserName());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole());

        if ("CUSTOMER".equalsIgnoreCase(request.getRole())) {
            user.setStatus("VERIFIED");
            User savedUser = userRepository.save(user);
            logger.debug("Customer user saved: {}", savedUser.getUserName());

            Customer customer = new Customer();
            customer.setName(request.getName());
            customer.setContactInfo(request.getContactInfo());
            customer.setEmail(request.getEmail());
            customer.setUser(savedUser);

            customerRepository.save(customer);
            logger.info("Customer profile created for user: {}", savedUser.getUserName());

        } else if ("SERVICE_AGENT".equalsIgnoreCase(request.getRole())) {
            user.setStatus("PENDING");
            User savedUser = userRepository.save(user);
            logger.debug("Service Agent user saved: {}", savedUser.getUserName());

            ServiceAgent agent = new ServiceAgent();
            agent.setName(request.getName());
            agent.setContactInfo(request.getContactInfo());
            agent.setSpecialization(request.getSpecialization());
            agent.setUser(savedUser);

            serviceAgentRepository.save(agent);
            logger.info("Service Agent profile created (pending approval) for user: {}", savedUser.getUserName());
        }

        return "Signup successful. Service Agent accounts require admin approval.";
    }

    public LoginResponse login(LoginRequest request) {
        logger.info("Login attempt for user: {}", request.getUserName());

        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUserName(), request.getPassword())
            );
        } catch (BadCredentialsException e) {
            logger.warn("Invalid credentials for user: {}", request.getUserName());
            throw new InvalidCredentialsException("Invalid credentials");
        }

        User user = userRepository.findByUserName(request.getUserName())
                .orElseThrow(() -> {
                    logger.error("User not found: {}", request.getUserName());
                    return new UserNotFoundException("User not found");
                });

        if ("SERVICE_AGENT".equalsIgnoreCase(user.getRole()) && !"VERIFIED".equalsIgnoreCase(user.getStatus())) {
            logger.warn("Service Agent not approved: {}", request.getUserName());
            throw new ServiceAgentNotApprovedException("Service Agent not yet approved by Admin.");
        }

        String token = jwtUtil.generateToken(user.getUserName(), user.getRole(), user.getStatus());
        logger.info("Login successful, token generated for user: {}", request.getUserName());

        return new LoginResponse(token, user.getRole(), user.getStatus());
    }
}