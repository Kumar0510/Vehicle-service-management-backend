package com.autotrack.servicescheduling.client;


import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "authservice")
public interface AuthClient {


}
