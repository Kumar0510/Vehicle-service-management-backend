package com.autotrack.servicescheduling.repository;

import com.autotrack.servicescheduling.model.ServicePartRelation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ServicePartRelationRepository extends JpaRepository<ServicePartRelation, Long> {

    /**
     * Finds all parts associated with a specific service.
     * Matches the 'serviceRecord' field in your ServicePartRelation model.
     */
    List<ServicePartRelation> findByServiceRecord_ServiceId(Long serviceId);

}