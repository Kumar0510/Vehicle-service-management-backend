package com.autotrack.servicescheduling.exception;


import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponseDto {
	private LocalDateTime timestamp;
	private int statusCode;
	private String error;
	private String message;
	private String path;
}
