package com.autotrack.servicescheduling.Dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServicePartRelationDto {

    @NotNull(message = "Service ID is required")
    private Long serviceId;

    @NotNull(message = "Part ID is required")
    private Long partId;

    @NotNull(message = "Relation ID is required for update")
    private Long relationId;

    @Min(value = 1, message = "Quantity must be at least 1")
    private int quantityUsed;
}