package com.autotrack.servicescheduling.client;

import com.autotrack.servicescheduling.Dto.PartsDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Feign Client to communicate with the Inventory Service.
 * The name must match 'spring.application.name' of the inventory service.
 */
@FeignClient(name = "inventoryservice", path = "/api/inventoryservice")
public interface InventoryClient {

    // Matches: GET /spare-parts
    @GetMapping("/spare-parts")
    List<PartsDto> getAllSpareParts();

    // Matches: GET /spare-parts/{id}
    @GetMapping("/spare-parts/{id}")
    PartsDto getSparePartById(@PathVariable("id") long id);

    // Matches: PUT /spare-parts/{id}/deduct
    @PutMapping("/spare-parts/{id}/deduct")
    void deductStock(
            @PathVariable("id") long id,
            @RequestParam("quantity") int quantity
    );

    // Matches: GET /spare-parts/low-in-stock
    @GetMapping("/spare-parts/low-in-stock")
    List<PartsDto> getAllLowStockParts();

    // Matches: PUT /spare-parts/{id}/reorder
    @PutMapping("/spare-parts/{id}/reorder")
    void reorderStock(
            @PathVariable("id") long id,
            @RequestParam("amount") int amount
    );
}