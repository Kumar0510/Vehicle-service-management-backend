package com.autotrack.servicescheduling.client;

import com.autotrack.servicescheduling.Dto.VehicleDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "vehicleservice")
public interface VehicleClient {
    @GetMapping("/api/vehicles/customer/{vId}")
    VehicleDTO getVehicleById(@RequestHeader("X-USER-ID") Long customerId,
                              @PathVariable("vId") Long vId);
}
