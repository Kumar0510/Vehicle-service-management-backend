package com.autotrack.servicescheduling.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDTO {
    // This must match the field names from your Vehicle Registration Service
    private Long vehicleId;
    private String vin;
    private String model;
    private int year;
    private String status;
}