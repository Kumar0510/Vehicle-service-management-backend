package com.autotrack.servicescheduling.model;

import com.autotrack.servicescheduling.model.ServicePartRelation;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "service_record")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServiceRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long serviceId;

    @Column(nullable = false)
    private String serviceType;

    @Column(nullable = false)
    private LocalDate scheduledDate;

    private LocalDate completionDate;
    private String status;

    // CHANGED: Using IDs for external services
    @Column(name = "vehicleId", nullable = false)
    private Long vehicleId;

    @Column(name = "serviceAgentId")
    private Long serviceAgentId;

    // KEPT: Relationship within the same database
    @OneToMany(mappedBy = "serviceRecord", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<ServicePartRelation> servicePartRelation;
}