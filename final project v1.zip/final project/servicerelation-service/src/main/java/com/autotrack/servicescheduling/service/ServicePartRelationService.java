package com.autotrack.servicescheduling.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.autotrack.servicescheduling.Dto.ServicePartRelationDto;
import com.autotrack.servicescheduling.exception.ResourceNotFoundException;
import com.autotrack.servicescheduling.exception.BadRequestException;
import com.autotrack.servicescheduling.exception.InvalidOperationException;

import com.autotrack.servicescheduling.model.ServicePartRelation;
import com.autotrack.servicescheduling.model.ServiceRecord;
import com.autotrack.servicescheduling.repository.ServicePartRelationRepository;
import com.autotrack.servicescheduling.repository.ServiceRecordRepository;
import com.autotrack.servicescheduling.client.InventoryClient; // Import Feign Client

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ServicePartRelationService {

    @Autowired
    private ServicePartRelationRepository servicePartRelationRepository;

    @Autowired
    private ServiceRecordRepository serviceRecordRepository;

    // CHANGED: Replaced SparePartRepository with InventoryClient
    @Autowired
    private InventoryClient inventoryClient;

    // ================= GET ALL RELATIONS =================
    public List<ServicePartRelation> getServicePartRecords() {
        log.info("API CALL: Fetching all service-part relation records");
        return servicePartRelationRepository.findAll();
    }

    // ================= GET RELATION BY ID =================
    public ServicePartRelation getServicePartRecordById(Long id) {
        log.info("API CALL: Fetch service-part relation for relationId={}", id);
        return servicePartRelationRepository.findById(id).orElseThrow(() -> {
            log.error("Service-part relation not found for relationId={}", id);
            return new ResourceNotFoundException("Service-part relation not found with id: " + id);
        });
    }

    // ================= DELETE RELATION =================
    public void deleteServicePartRecord(Long id) {
        log.info("API CALL: Delete service-part relation for relationId={}", id);
        ServicePartRelation relation = servicePartRelationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Relation not found with id: " + id));

        servicePartRelationRepository.delete(relation);
        log.info("Service-part relation deleted successfully for relationId={}", id);
    }

    // ================= SAVE RELATION USING DTO =================
    public String saveRelation(ServicePartRelationDto dto) {
        log.info("API CALL: Create service-part relation | serviceId={}, partId={}",
                dto.getServiceId(), dto.getPartId());

        if (dto.getQuantityUsed() <= 0) {
            throw new BadRequestException("Quantity must be greater than zero");
        }

        // 1. Verify Local Service Record
        ServiceRecord sr = serviceRecordRepository.findById(dto.getServiceId())
                .orElseThrow(() -> new ResourceNotFoundException("Service not found with id: " + dto.getServiceId()));

        if (!sr.getStatus().equalsIgnoreCase("pending")) {
            throw new InvalidOperationException("Cannot add spare parts once service is accepted");
        }

        // 2. CROSS-SERVICE CALL: Verify and Deduct Stock via Inventory Service
        // This replaces the old sparePartRepository.findById() check
        try {
            inventoryClient.deductStock(dto.getPartId(), dto.getQuantityUsed());
            log.info("Inventory updated successfully for PartId: {}", dto.getPartId());
        } catch (Exception e) {
            log.error("Failed to update inventory for PartId: {}. Error: {}", dto.getPartId(), e.getMessage());
            throw new BadRequestException("Stock deduction failed or part not found in Inventory Service");
        }

        // 3. Save Local Relation using the new ID-based Model
        ServicePartRelation relation = new ServicePartRelation();
        relation.setServiceRecord(sr);
        relation.setPartId(dto.getPartId()); // Storing the raw Long ID
        relation.setQuantityUsed(dto.getQuantityUsed());

        servicePartRelationRepository.save(relation);

        return "Successfully saved relation and deducted stock from Inventory";
    }

    // ================= UPDATE RELATION USING DTO =================
    public String updateRelation(ServicePartRelationDto dto) {
        log.info("API CALL: Update service-part relation for relationId={}", dto.getRelationId());

        if (dto.getQuantityUsed() <= 0) {
            throw new BadRequestException("Quantity must be greater than zero");
        }

        ServicePartRelation rel = servicePartRelationRepository.findById(dto.getRelationId())
                .orElseThrow(() -> new ResourceNotFoundException("Relation not found with id: " + dto.getRelationId()));

        // Check if internal link to ServiceRecord is still pending
        if (!rel.getServiceRecord().getStatus().equalsIgnoreCase("pending")) {
            throw new InvalidOperationException("Cannot update spare parts once service is accepted");
        }

        // Note: For a proper microservice update, you'd calculate the difference
        // and call inventoryClient again to adjust stock, but we'll stick to basic update for now.
        rel.setQuantityUsed(dto.getQuantityUsed());
        servicePartRelationRepository.save(rel);

        return "Updated successfully";
    }

    // for invoice part
    public List<ServicePartRelationDto> getRelationsByServiceId(Long serviceId) {
        log.info("Fetching service part relations for service ID: {}", serviceId);

        List<ServicePartRelation> relations = servicePartRelationRepository.findByServiceRecord_ServiceId(serviceId);
        return relations.stream()
                .map(relation -> convertToDto(relation, serviceId))
                .toList();
    }

    // Notice we added the knownServiceId parameter here
    private ServicePartRelationDto convertToDto(ServicePartRelation relation, Long knownServiceId) {
        ServicePartRelationDto dto = new ServicePartRelationDto();

        dto.setRelationId(relation.getRelationId());
        dto.setServiceId(knownServiceId);
        dto.setPartId(relation.getPartId());
        dto.setQuantityUsed(relation.getQuantityUsed());

        return dto;
    }
}