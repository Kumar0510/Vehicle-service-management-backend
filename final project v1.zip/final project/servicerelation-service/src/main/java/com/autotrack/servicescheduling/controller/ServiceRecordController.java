package com.autotrack.servicescheduling.controller;

import java.util.List;

import com.autotrack.servicescheduling.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.autotrack.servicescheduling.Dto.AgentServiceListDto;
import com.autotrack.servicescheduling.Dto.PartsDto;
import com.autotrack.servicescheduling.Dto.ServiceFullDetailsDto;
import com.autotrack.servicescheduling.Dto.ServiceListDto;
import com.autotrack.servicescheduling.Dto.ServiceRequestDto;
import com.autotrack.servicescheduling.Dto.ServiceResponseDto;
import com.autotrack.servicescheduling.model.ServiceRecord;
import com.autotrack.servicescheduling.service.ServiceRecordService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/serviceRecord")
public class ServiceRecordController {

    @Autowired
    private ServiceRecordService serviceRecordService;

    @PostMapping("/insert/record")
    public void saveServiceRecord(@RequestBody ServiceRecord serviceRecord) {
        log.info("API REQUEST: Insert raw service record");
        serviceRecordService.saveServiceRecord(serviceRecord);
    }

    @PutMapping("/update/record")
    public String updateServiceRecord(@RequestBody ServiceRecord serviceRecord) {
        log.info("API REQUEST: Update service record | serviceId={}", serviceRecord.getServiceId());
        return serviceRecordService.updateServiceRecord(serviceRecord);
    }

    @GetMapping("/get/all")
    public List<ServiceRecord> getAllServiceRecords() {
        log.info("API REQUEST: Fetch all service records");
        return serviceRecordService.getAllServiceRecords();
    }

    @DeleteMapping("/delete/{id}")
    public String deleteServiceRecord(@PathVariable Long id) {
        log.info("API REQUEST: Delete service record | serviceId={}", id);
        return serviceRecordService.deleteServiceRecord(id);
    }

    @GetMapping("/get/{id}")
    public ServiceRecord getServiceRecordById(@PathVariable Long id) {
        log.info("API REQUEST: Get service record | serviceId={}", id);
        return serviceRecordService.getServiceRecordById(id);
    }

    @PostMapping("/create")
    public ServiceResponseDto createServiceRecord(@RequestHeader("X-USER-ID") Long userId,
                                                  @Valid @RequestBody ServiceRequestDto serviceRequestDto ) {
        log.info("API REQUEST: Create service | vehicleId={}", serviceRequestDto.getVehicleId());

        return serviceRecordService.createServiceRecord(userId, serviceRequestDto);
    }

    // ARCHITECTURAL SHIFT: New endpoint added to allow agents to explicitly request parts
    // after accepting a service, replacing the monolithic flow where parts were requested at the time of booking.
    @PostMapping("/update/parts/{serviceId}")
    public String addPartsToService(
            @PathVariable Long serviceId,
            @RequestHeader("X-USER-ID") Long agentId,
            @RequestBody List<PartsDto> parts) {

        log.info("API REQUEST: Agent {} adding parts to service {}", agentId, serviceId);
        return serviceRecordService.requestPartsForService(serviceId, agentId, parts);
    }

    @PatchMapping("/update/status/{id}/{agentId}")
    public String acceptStatus(@PathVariable Long id, @PathVariable Long agentId) {
        log.info("API REQUEST: Agent {} accepting service {}", agentId, id);
        return serviceRecordService.acceptStatus(id, agentId);
    }

    @PatchMapping("/update/status/completed/{id}/")
    public String updateStatus(@PathVariable Long id) {
        log.info("API REQUEST: Complete service | serviceId={}", id);
        return serviceRecordService.updateStatus(id);
    }

    @PatchMapping("/update/status/cancel/{id}/")
    public String cancelStatus(@PathVariable Long id) {
        log.info("API REQUEST: Cancel service | serviceId={}", id);
        return serviceRecordService.cancelStatus(id);
    }

    @GetMapping("/customer/{customerID}")
    public List<ServiceRecord> getCustomerServiceHistory(@PathVariable Long customerID) {
        log.info("API REQUEST: Fetch service history | customerId={}", customerID);
        return serviceRecordService.getServicesByCustomer(customerID);
    }

    // ARCHITECTURAL SHIFT: Added X-USER-ID header so the controller can pass it down
    // to the Service layer for Vehicle authentication.
    @GetMapping("/details/{serviceId}")
    public ServiceFullDetailsDto getFullDetails(
            @RequestHeader("X-USER-ID") Long userId,
            @PathVariable Long serviceId) {
        log.info("API REQUEST: Fetch full service details | serviceId={}", serviceId);
        return serviceRecordService.getFullServiceDetails(serviceId, userId);
    }

    @GetMapping("/agent/{agentId}")
    public List<ServiceRecord> getAgentServices(@PathVariable Long agentId) {
        log.info("API REQUEST: Fetch services for agentId={}", agentId);
        return serviceRecordService.getServicesForAgent(agentId);
    }

    @GetMapping("/customer/list/{customerID}")
    public List<ServiceListDto> getCustomerServiceList(@PathVariable Long customerID) {
        log.info("API REQUEST: Fetch customer service list | customerId={}", customerID);
        return serviceRecordService.getCustomerServiceList(customerID);
    }

    @GetMapping("/agent/list/{agentId}")
    public List<AgentServiceListDto> getAgentServiceList(@PathVariable Long agentId) {
        log.info("API REQUEST: Fetch agent service list | agentId={}", agentId);
        return serviceRecordService.getAgentServiceList(agentId);
    }
}