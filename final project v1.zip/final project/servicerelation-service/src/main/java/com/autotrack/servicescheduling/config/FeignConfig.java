package com.autotrack.servicescheduling.config;

import feign.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignConfig {
    @Bean
    Logger.Level feignLoggerLevel() {
        // FULL logs headers, body, and metadata for both requests and responses
        return Logger.Level.FULL;
    }
}