package com.autotrack.servicescheduling.repository;

import com.autotrack.servicescheduling.model.ServiceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ServiceRecordRepository extends JpaRepository<ServiceRecord, Long> {

    /**
     * Finds all service history for a vehicle.
     * Used by getServicesByCustomer and getCustomerServiceList.
     */
    List<ServiceRecord> findByVehicleId(Long vehicleId);

    /**
     * Finds all services assigned to a specific mechanic.
     * Used by getServicesForAgent and getAgentServiceList.
     */
    List<ServiceRecord> findByServiceAgentId(Long serviceAgentId);
}