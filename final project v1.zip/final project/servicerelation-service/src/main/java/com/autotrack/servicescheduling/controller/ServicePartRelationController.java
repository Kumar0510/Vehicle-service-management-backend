package com.autotrack.servicescheduling.controller;

import com.autotrack.servicescheduling.Dto.ServicePartRelationDto;
import com.autotrack.servicescheduling.model.ServicePartRelation;
import com.autotrack.servicescheduling.service.ServicePartRelationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequestMapping("/api/servicePartRelation")
public class ServicePartRelationController {

    @Autowired
    private ServicePartRelationService servicePartRelationService;

    @GetMapping("/service/{serviceId}")
    public ResponseEntity<List<ServicePartRelationDto>> getPartsUsedForService(@PathVariable Long serviceId) {
        log.info("Request received: Fetch parts used for service ID {}", serviceId);
        List<ServicePartRelationDto> response = servicePartRelationService.getRelationsByServiceId(serviceId);
        return ResponseEntity.ok(response);
    }

    // ================= GET ALL RELATIONS =================

    // API call to fetch all service-part relation records
    @GetMapping("/get/all")
    public List<ServicePartRelation> getServicePartRecords() {

        log.info("API REQUEST: Get all service-part relations");

        List<ServicePartRelation> records =
                servicePartRelationService.getServicePartRecords();

        log.info("API RESPONSE: Retrieved {} service-part relation records",
                records.size());

        return records;
    }

    // ================= GET RELATION BY ID =================

    // API call to fetch service-part relation by ID
    @GetMapping("/get/{id}")
    public ServicePartRelation getServicePartRecordById(@PathVariable("id") Long id) {

        log.info("API REQUEST: Get service-part relation by relationId={}", id);

        ServicePartRelation record =
                servicePartRelationService.getServicePartRecordById(id);

        log.info("API RESPONSE: Returning service-part relation for relationId={}", id);

        return record;
    }

    // ================= DELETE RELATION =================

    // API call to delete service-part relation by ID
    @DeleteMapping("/delete/{id}")
    public void deleteServicePartRecord(@PathVariable Long id) {

        log.info("API REQUEST: Delete service-part relation for relationId={}", id);

        servicePartRelationService.deleteServicePartRecord(id);

        log.info("API RESPONSE: Deleted service-part relation for relationId={}", id);
    }

    // ================= CREATE RELATION =================

    // API call to create a new service-part relation using DTO
    @PostMapping("/insert")
    public String saveRelation(@RequestBody ServicePartRelationDto dto) {

        log.info(
            "API REQUEST: Create service-part relation | serviceId={}, partId={}, quantity={}",
            dto.getServiceId(),
            dto.getPartId(),
            dto.getQuantityUsed()
        );

        String response = servicePartRelationService.saveRelation(dto);

        log.info("API RESPONSE: {}", response);

        return response;
    }

    // ================= UPDATE RELATION =================

    // API call to update quantity of an existing service-part relation
    @PostMapping("/update")
    public String updateRelation(@RequestBody ServicePartRelationDto dto) {

        log.info(
            "API REQUEST: Update service-part relation | relationId={}, newQuantity={}",
            dto.getRelationId(),
            dto.getQuantityUsed()
        );

        String response = servicePartRelationService.updateRelation(dto);

        log.info("API RESPONSE: {}", response);

        return response;
    }
}