package com.autotrack.servicescheduling.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServiceResponseDto {
    private Long serviceId;
    private String serviceType;
    private LocalDate scheduledDate;
    private LocalDate completionDate;
    private String status;
    private List<PartsDto> partsDtoList;

}
