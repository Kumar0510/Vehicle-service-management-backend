package com.autotrack.servicescheduling.Dto;

import lombok.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AgentServiceListDto {

    private Long serviceId;
    private String serviceType;
    private LocalDate scheduledDate;
    private String status;

    private Long customerId;
    private String customerName;

    private Long vehicleId;
    private String vehicleModel;
}