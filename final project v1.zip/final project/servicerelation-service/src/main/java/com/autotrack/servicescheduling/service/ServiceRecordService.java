package com.autotrack.servicescheduling.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.autotrack.servicescheduling.client.AuthClient;
import com.autotrack.servicescheduling.client.VehicleClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.autotrack.servicescheduling.Dto.*;
import com.autotrack.servicescheduling.client.InventoryClient;
import com.autotrack.servicescheduling.exception.InvalidOperationException;
import com.autotrack.servicescheduling.exception.ResourceNotFoundException;
import com.autotrack.servicescheduling.model.ServicePartRelation;
import com.autotrack.servicescheduling.model.ServiceRecord;
import com.autotrack.servicescheduling.repository.ServicePartRelationRepository;
import com.autotrack.servicescheduling.repository.ServiceRecordRepository;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ServiceRecordService {

    @Autowired
    private ServiceRecordRepository serviceRecordRepository;

    @Autowired
    private ServicePartRelationRepository servicePartRelationRepository;

    @Autowired
    private InventoryClient inventoryClient;

    @Autowired
    private VehicleClient vehicleClient;

    @Autowired
    private AuthClient authClient;

    public void saveServiceRecord(ServiceRecord serviceRecord) {
        log.info("API CALL: Save service record initiated");
        serviceRecordRepository.save(serviceRecord);
    }

    public String updateServiceRecord(ServiceRecord serviceRecord) {
        ServiceRecord sr = serviceRecordRepository.findById(serviceRecord.getServiceId())
                .orElseThrow(() -> new ResourceNotFoundException("Service not found"));

        if (!sr.getStatus().equalsIgnoreCase("pending")) {
            throw new InvalidOperationException("Only pending services can be updated");
        }

        sr.setServiceType(serviceRecord.getServiceType());
        sr.setScheduledDate(serviceRecord.getScheduledDate());
        serviceRecordRepository.save(sr);
        return "Updated successfully";
    }

    public List<ServiceRecord> getAllServiceRecords() {
        return serviceRecordRepository.findAll();
    }

    public String deleteServiceRecord(Long id) {
        ServiceRecord sr = serviceRecordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Service not found"));

        if (!sr.getStatus().equalsIgnoreCase("pending")) {
            throw new InvalidOperationException("Only pending services can be deleted");
        }

        serviceRecordRepository.delete(sr);
        return "Service record deleted successfully";
    }

    public ServiceRecord getServiceRecordById(Long id) {
        return serviceRecordRepository.findById(id).orElse(new ServiceRecord());
    }

    @Transactional
    public ServiceResponseDto createServiceRecord(Long userId, ServiceRequestDto serviceRequestDto) {
        log.info("MICROSERVICE CALL: Create service for vehicleId={}", serviceRequestDto.getVehicleId());

        try {
            vehicleClient.getVehicleById(userId, serviceRequestDto.getVehicleId());
        } catch (Exception e) {
            log.error("Vehicle validation failed: {}", e.getMessage());
            throw new ResourceNotFoundException("Vehicle not found or does not belong to user");
        }

        ServiceRecord record = new ServiceRecord();
        record.setVehicleId(serviceRequestDto.getVehicleId());
        record.setServiceType(serviceRequestDto.getServiceType());
        record.setScheduledDate(LocalDate.parse(serviceRequestDto.getScheduledDate()));
        record.setCompletionDate(LocalDate.parse(serviceRequestDto.getScheduledDate()));
        record.setStatus("pending");

        record = serviceRecordRepository.save(record);

        // ARCHITECTURAL SHIFT: Previously, the InventoryClient.deductStock logic and ServicePartRelation mapping
        // happened right here during booking. This logic was completely removed from this initial step to prevent
        // distributed transaction failures if the inventory service fails. It has been moved to the
        // requestPartsForService method so agents handle it after job acceptance.

        return new ServiceResponseDto(record.getServiceId(), record.getServiceType(),
                record.getScheduledDate(), record.getCompletionDate(),
                record.getStatus(), new ArrayList<>());
    }

    // ARCHITECTURAL SHIFT: This method is entirely new. It houses the part deduction logic previously found
    // in createServiceRecord. It ensures parts are only deducted AFTER an agent accepts the job and ONLY
    // by the assigned agent, matching real-world garage workflows.
    @Transactional
    public String requestPartsForService(Long serviceId, Long agentId, List<PartsDto> partsDtoList) {
        log.info("MICROSERVICE CALL: Agent {} requesting parts for serviceId={}", agentId, serviceId);

        ServiceRecord sr = serviceRecordRepository.findById(serviceId)
                .orElseThrow(() -> new ResourceNotFoundException("Service not found"));

        if (!sr.getStatus().equalsIgnoreCase("accepted")) {
            throw new InvalidOperationException("Parts can only be added to jobs that are 'accepted'.");
        }

        if (!agentId.equals(sr.getServiceAgentId())) {
            throw new InvalidOperationException("Access Denied: You are not assigned to this service record.");
        }

        if (partsDtoList != null && !partsDtoList.isEmpty()) {
            for (PartsDto part : partsDtoList) {
                inventoryClient.deductStock(part.getPartId(), part.getQuantityUsed());

                ServicePartRelation relation = new ServicePartRelation();
                relation.setServiceRecord(sr);
                relation.setPartId(part.getPartId());
                relation.setQuantityUsed(part.getQuantityUsed());
                servicePartRelationRepository.save(relation);
            }
        } else {
            throw new InvalidOperationException("Part list cannot be empty.");
        }

        return "Parts successfully deducted from inventory and added to the service record.";
    }

    public String acceptStatus(Long id, Long agentId) {
        ServiceRecord sr = serviceRecordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Service not found"));

        if (!sr.getStatus().equalsIgnoreCase("pending")) {
            throw new InvalidOperationException("Service cannot be accepted in current state");
        }

        sr.setServiceAgentId(agentId);
        sr.setStatus("accepted");
        serviceRecordRepository.save(sr);
        return "Service accepted successfully";
    }

    public String updateStatus(Long id) {
        ServiceRecord sr = serviceRecordRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Service not found"));

        if (sr.getStatus().equalsIgnoreCase("accepted")) {
            sr.setStatus("Completed");
            sr.setCompletionDate(LocalDate.now());
            serviceRecordRepository.save(sr);
            return "marked as completed";
        }
        return "service request not yet accepted";
    }

    public String cancelStatus(Long id) {
        ServiceRecord sr = serviceRecordRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Service not found"));

        if (sr.getStatus().equalsIgnoreCase("pending")) {
            sr.setStatus("Cancelled");
            sr.setCompletionDate(LocalDate.now());
            serviceRecordRepository.save(sr);
            return "service was cancelled";
        }
        return "cannot cancel the service record";
    }

    // ARCHITECTURAL SHIFT: Added userId parameter so the Feign client can authenticate the request
    // securely with the Vehicle module.
    public ServiceFullDetailsDto getFullServiceDetails(Long serviceId, Long userId) {
        ServiceRecord sr = serviceRecordRepository.findById(serviceId)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid Service ID"));

        List<ServicePartRelation> relations = servicePartRelationRepository.findByServiceRecord_ServiceId(serviceId);
        List<PartsDto> partsDtoList = relations.stream()
                .map(rel -> new PartsDto(rel.getPartId(), rel.getQuantityUsed()))
                .collect(Collectors.toList());

        ServiceFullDetailsDto dto = new ServiceFullDetailsDto();
        dto.setServiceId(sr.getServiceId());
        dto.setServiceType(sr.getServiceType());
        dto.setScheduledDate(sr.getScheduledDate());
        dto.setCompletionDate(sr.getCompletionDate());
        dto.setStatus(sr.getStatus());
        dto.setVehicleId(sr.getVehicleId());

        try {
            VehicleDTO vehicleDTO = vehicleClient.getVehicleById(userId, sr.getVehicleId());
            dto.setVehicleModel(vehicleDTO.getModel());
            dto.setVehicleVin(vehicleDTO.getVin());
        } catch (Exception e) {
            log.error("Failed to fetch vehicle details for vehicleId {}: {}", sr.getVehicleId(), e.getMessage());
            dto.setVehicleModel("Details Unavailable");
            dto.setVehicleVin("Details Unavailable");
        }

        if (sr.getServiceAgentId() != null) {
            dto.setAgentId(sr.getServiceAgentId());
            dto.setAgentName("FETCH_NAME_FROM_AUTH_SERVICE");
        }

        dto.setPartsList(partsDtoList);
        return dto;
    }

    public List<ServiceRecord> getServicesByCustomer(Long customerID) {
        return serviceRecordRepository.findByVehicleId(customerID);
    }

    public List<ServiceListDto> getCustomerServiceList(Long customerID) {
        List<ServiceRecord> records = serviceRecordRepository.findByVehicleId(customerID);

        return records.stream().map(sr -> {
            String actualModel = "Unknown Model";
            try {
                VehicleDTO vehicleDTO = vehicleClient.getVehicleById(customerID, sr.getVehicleId());
                actualModel = vehicleDTO.getModel();
            } catch (Exception e) {
                log.warn("Could not fetch model for vehicleId {}: {}", sr.getVehicleId(), e.getMessage());
            }

            return new ServiceListDto(
                    sr.getServiceId(), sr.getServiceType(), sr.getScheduledDate(),
                    sr.getStatus(), sr.getVehicleId(), actualModel
            );
        }).collect(Collectors.toList());
    }

    public List<AgentServiceListDto> getAgentServiceList(Long agentId) {
        List<ServiceRecord> records = serviceRecordRepository.findByServiceAgentId(agentId);
        return records.stream().map(sr -> new AgentServiceListDto(
                sr.getServiceId(), sr.getServiceType(), sr.getScheduledDate(),
                sr.getStatus(), 0L, "CUSTOMER_NAME_PLACEHOLDER", sr.getVehicleId(), "VEHICLE_MODEL_PLACEHOLDER"
        )).collect(Collectors.toList());
    }

    public List<ServiceRecord> getServicesForAgent(Long agentId) {
        return serviceRecordRepository.findByServiceAgentId(agentId);
    }
}