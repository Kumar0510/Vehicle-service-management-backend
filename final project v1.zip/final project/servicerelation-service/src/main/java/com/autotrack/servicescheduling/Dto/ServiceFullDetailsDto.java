package com.autotrack.servicescheduling.Dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServiceFullDetailsDto {

    private Long serviceId;
    private String serviceType;
    private LocalDate scheduledDate;
    private LocalDate completionDate;
    private String status;

    // Vehicle
    private Long vehicleId;
    private String vehicleModel;
    private String vehicleVin;

    // Agent
    private Long agentId;
    private String agentName;
    private String agentSpecialization;

    // Parts used
    private List<PartsDto> partsList;

}
