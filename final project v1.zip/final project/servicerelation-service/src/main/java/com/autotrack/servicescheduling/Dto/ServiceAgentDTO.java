package com.autotrack.servicescheduling.Dto;

public class ServiceAgentDTO {

}
