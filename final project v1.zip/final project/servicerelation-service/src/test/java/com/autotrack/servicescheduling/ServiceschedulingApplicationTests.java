package com.autotrack.servicescheduling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceschedulingApplicationTests {

	@Test
	void contextLoads() {
	}

}
