package com.autotrack.servicescheduling.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.autotrack.servicescheduling.model.ServiceRecord;
import com.autotrack.servicescheduling.repository.ServiceRecordRepository;

@ExtendWith(MockitoExtension.class)
class ServiceRecordServiceTest {

    @Mock
    private ServiceRecordRepository serviceRecordRepository;

    @Mock
    private ServiceAgentRepository serviceAgentRepository;

    @InjectMocks
    private ServiceRecordService service;

    @Test
    void updateServiceRecord_success() {
        ServiceRecord existing = new ServiceRecord();
        existing.setServiceId(1L);
        existing.setStatus("pending");

        ServiceRecord update = new ServiceRecord();
        update.setServiceId(1L);
        update.setScheduledDate(LocalDate.now());

        when(serviceRecordRepository.findById(1L))
            .thenReturn(Optional.of(existing));

        String result = service.updateServiceRecord(update);

        assertEquals("Updated successfully", result);
        verify(serviceRecordRepository).save(existing);
    }
}
