//package com.autotrack.servicescheduling.service;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.autotrack.servicescheduling.Dto.ServicePartRelationDto;
//import com.autotrack.servicescheduling.exception.BadRequestException;
//import com.autotrack.servicescheduling.exception.InvalidOperationException;
//import com.autotrack.servicescheduling.exception.ResourceNotFoundException;
//import com.autotrack.servicescheduling.model.ServicePartRelation;
//import com.autotrack.servicescheduling.model.ServiceRecord;
//import com.autotrack.servicescheduling.repository.ServicePartRelationRepository;
//import com.autotrack.servicescheduling.repository.ServiceRecordRepository;
//
//@ExtendWith(MockitoExtension.class)
//class ServicePartRelationServiceTest {
//
//    @Mock
//    private ServicePartRelationRepository relationRepository;
//
//    @Mock
//    private ServiceRecordRepository serviceRecordRepository;
//
//    @Mock
//    private SparePartRepository sparePartRepository;
//
//    @InjectMocks
//    private ServicePartRelationService service;
//
//    // ✅ saveServicePartRelationRecord
//    @Test
//    void saveServicePartRelationRecord_success() {
//        ServicePartRelation relation = new ServicePartRelation();
//
//        service.saveServicePartRelationRecord(relation);
//
//        verify(relationRepository, times(1)).save(relation);
//    }
//
//    // ✅ getServicePartRecordById - success
//    @Test
//    void getServicePartRecordById_success() {
//        ServicePartRelation relation = new ServicePartRelation();
//        when(relationRepository.findById(1L)).thenReturn(Optional.of(relation));
//
//        ServicePartRelation result = service.getServicePartRecordById(1L);
//
//        assertNotNull(result);
//    }
//
//    // ✅ getServicePartRecordById - not found
//    @Test
//    void getServicePartRecordById_notFound() {
//        when(relationRepository.findById(1L)).thenReturn(Optional.empty());
//
//        assertThrows(ResourceNotFoundException.class,
//                () -> service.getServicePartRecordById(1L));
//    }
//
//    // ✅ deleteServicePartRecord - success
//    @Test
//    void deleteServicePartRecord_success() {
//        ServicePartRelation relation = new ServicePartRelation();
//        when(relationRepository.findById(1L)).thenReturn(Optional.of(relation));
//
//        service.deleteServicePartRecord(1L);
//
//        verify(relationRepository).delete(relation);
//    }
//
//    // ✅ saveRelation - invalid quantity
//    @Test
//    void saveRelation_invalidQuantity() {
//        ServicePartRelationDto dto = new ServicePartRelationDto();
//        dto.setQuantityUsed(0);
//
//        assertThrows(BadRequestException.class,
//                () -> service.saveRelation(dto));
//    }
//
//    // ✅ saveRelation - service not pending
//    @Test
//    void saveRelation_serviceNotPending() {
//        ServiceRecord sr = new ServiceRecord();
//        sr.setStatus("accepted");
//
//        ServicePartRelationDto dto = new ServicePartRelationDto();
//        dto.setServiceId(1L);
//        dto.setQuantityUsed(2);
//
//        when(serviceRecordRepository.findById(1L))
//                .thenReturn(Optional.of(sr));
//
//        assertThrows(InvalidOperationException.class,
//                () -> service.saveRelation(dto));
//    }
//
//    // ✅ updateRelation - success
//    @Test
//    void updateRelation_success() {
//        ServiceRecord sr = new ServiceRecord();
//        sr.setStatus("pending");
//
//        ServicePartRelation relation = new ServicePartRelation();
//        relation.setServiceRecord(sr);
//
//        ServicePartRelationDto dto = new ServicePartRelationDto();
//        dto.setRelationId(1L);
//        dto.setQuantityUsed(5);
//
//        when(relationRepository.findById(1L))
//                .thenReturn(Optional.of(relation));
//
//        String result = service.updateRelation(dto);
//
//        assertEquals("Updated successfully", result);
//        verify(relationRepository).save(relation);
//    }
//}