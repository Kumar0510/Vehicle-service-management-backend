package com.autotrack.servicescheduling.exception;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ResourceNotFoundExceptionTest {

    @Test
    void testMessage() {
        String msg = "Resource not found";
        ResourceNotFoundException ex = new ResourceNotFoundException(msg);
        assertEquals(msg, ex.getMessage());
    }
}
