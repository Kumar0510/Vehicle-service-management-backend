package com.autotrack.servicescheduling.exception;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import jakarta.servlet.http.HttpServletRequest;

import static org.mockito.Mockito.*;

class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler handler;
    private HttpServletRequest request;

    @BeforeEach
    void setup() {
        handler = new GlobalExceptionHandler();
        request = mock(HttpServletRequest.class);
        when(request.getRequestURI()).thenReturn("/test");
    }

    @Test
    void handleResourceNotFound() {
        ResourceNotFoundException ex =
                new ResourceNotFoundException("Not found");

        ResponseEntity<ErrorResponseDto> response =
                handler.handleResourceNotFoundException(ex, request);

        assertEquals(404, response.getStatusCodeValue());
        assertEquals("NOT_FOUND", response.getBody().getError());
    }

    @Test
    void handleBadRequest() {
        BadRequestException ex =
                new BadRequestException("Invalid input");

        ResponseEntity<ErrorResponseDto> response =
                handler.handleBadRequestException(ex, request);

        assertEquals(400, response.getStatusCodeValue());
        assertEquals("BAD_REQUEST", response.getBody().getError());
    }

    @Test
    void handleInvalidOperation() {
        InvalidOperationException ex =
                new InvalidOperationException("Operation not allowed");

        ResponseEntity<ErrorResponseDto> response =
                handler.handleInvalidOperationException(ex, request);

        assertEquals(409, response.getStatusCodeValue());
        assertEquals("INVALID_OPERATION", response.getBody().getError());
    }
}