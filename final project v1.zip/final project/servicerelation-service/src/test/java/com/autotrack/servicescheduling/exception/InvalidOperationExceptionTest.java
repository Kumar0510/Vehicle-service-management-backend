package com.autotrack.servicescheduling.exception;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class InvalidOperationExceptionTest {

    @Test
    void testMessage() {
        String msg = "Invalid operation";
        InvalidOperationException ex = new InvalidOperationException(msg);
        assertEquals(msg, ex.getMessage());
    }
}
